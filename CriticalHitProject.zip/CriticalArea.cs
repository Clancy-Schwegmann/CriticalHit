using Godot;
using System;

public class CriticalArea : Node2D
{
	private void _on_thisArea_area_entered(object area)
	{
		//GD.Print(area);
	// Replace with function body.
	}
	private void CheckArea()
	{
		
	}
	
	// Declare member variables here. Examples:
	// private int a = 2;
	// private string b = "text";
	public RectangleShape2D thisShape;
	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
	thisShape = GetNode<CollisionShape2D>("Critical_Area/thisArea/criticalCollider").GetShape() as RectangleShape2D;
	}
	
	public void ScaleMethod(float inputScale,out float outputExtents)
	{
		this.Scale = new Vector2(inputScale,this.Scale.y);
		outputExtents = thisShape.Extents.x;
//		return outputExtents;
	}

	public void Kill()
	{
		QueueFree();
	}


//  // Called every frame. 'delta' is the elapsed time since the previous frame.
//  public override void _Process(float delta)
//  {
//      
//  }
}



