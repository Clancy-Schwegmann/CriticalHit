using Godot;
using System;

public class SoundController : TouchScreenButton
{
	// Declare member variables here. Examples:
	// private int a = 2;
	// private string b = "text";
	public AudioStreamPlayer deathSFX;
	public AudioStreamPlayer hitSFX;
	
	//Autoloaded script, used for transitioning scenes.
	public transitionTest sceneTransition;


	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
		deathSFX = GetNode("deathSound") as AudioStreamPlayer;
		hitSFX = GetNode("criticalHitSound") as AudioStreamPlayer;
		
		//Declare stuff
		sceneTransition = GetNode<transitionTest>("/root/sceneSwitcher/transitionTest");
	}
	
	private void _on_SoundController_released()
	{
		//flip variable
		sceneTransition.muteSound = !sceneTransition.muteSound;
		if(sceneTransition.muteSound == false)
			sceneTransition.saveDict["muteSound"] = "false";
		else
			sceneTransition.saveDict["muteSound"] = "true";
		sceneTransition.SaveGame();
		// Replace with function body.
	}

	public void playDead()
	{
		if(!sceneTransition.muteSound)
			deathSFX.Play();
	}
	
	public void playHit()
	{
		if(!sceneTransition.muteSound)
			hitSFX.Play();
	}
//  // Called every frame. 'delta' is the elapsed time since the previous frame.
  public override void _Process(float delta)
	{
		//Display soundtoggle as well, meaning sound button should look pressed if turned off.
		if(sceneTransition.muteSound)
		{
			this.Normal = (Texture)ResourceLoader.Load("res://GFX_Folder/Headphones_3.png");
			this.Pressed = (Texture)ResourceLoader.Load("res://GFX_Folder/Headphones_3.png");
		}
		else if(!sceneTransition.muteSound)
		{
			this.Normal = (Texture)ResourceLoader.Load("res://GFX_Folder/Headphones_1.png");
			this.Pressed = (Texture)ResourceLoader.Load("res://GFX_Folder/Headphones_2.png");
		}
	}
}



