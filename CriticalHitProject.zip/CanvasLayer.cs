using Godot;
using System;

public class CanvasLayer : Godot.CanvasLayer
{

}
