using Godot;
using System;
using System.Collections.Generic;

public class MainNode : Node2D
{
	
	//Random crap
		private Texture pinkTexture1;
		private Texture pinkTexture2;
		private Texture pinkTexture3;
		private Texture pinkTexture4;
		private Texture pinkTexture5;
		
		private Texture greenTexture1;
		private Texture greenTexture2;
		private Texture greenTexture3;
		private Texture greenTexture4;
		private Texture greenTexture5;
		
		private Texture brownTexture1;
		private Texture brownTexture2;
		private Texture brownTexture3;
		private Texture brownTexture4;
		private Texture brownTexture5;
		
		private Texture blackTexture1;
		private Texture blackTexture2;
		private Texture blackTexture3;
		private Texture blackTexture4;
		private Texture blackTexture5;
		
		private Texture purpleTexture1;
		private Texture purpleTexture2;
		private Texture purpleTexture3;
		private Texture purpleTexture4;
		private Texture purpleTexture5;
		
		private Texture blueTexture1;
		private Texture blueTexture2;
		private Texture blueTexture3;
		private Texture blueTexture4;
		private Texture blueTexture5;
		
		private Texture redTexture1;
		private Texture redTexture2;
		private Texture redTexture3;
		private Texture redTexture4;
		private Texture redTexture5;
	//
	
//Init settings - before game starts.
	//Should we start game yet? or wait for fade.
	public bool startGame = true;
	//Autoloaded script, used for transitioning scenes.
	public transitionTest sceneTransition;
	private bool saveCheck = false;
	
	//Score-Attack settings
	//Easy,medium,hard
	
	//timer might lower as the player progresses though.
	private string[] scoreAttackArray = {"30 Seconds","10 Seconds","5 Seconds"}; 
	

//Initialize spawn locations and stuff.
	private Camera2D mainCamera;
	//After scaling the area, check if the area is out of the bar's range, then
	//translate the position left or right until the area is in range.
	public RectangleShape2D meterShape;
	private Sprite meterBar;
	private Sprite meterSprite;
//

//Enemy components

	//Enemy movement types:
	
	//Waypoint - means enemies only move between two places.
	//Random - random positions are selected.
	private string enemyMovement = "Random";
	//Game Mode
	private string gameMode = "TimeAttack";
	
	//Spawning and instance settings.
		private Node2D criticalSet;
		private Node2D criticalInstance;
		private PackedScene criticalArea;
		private Node2D enemyInstance;
	//
	

//Player variables.
	private RectangleShape2D playerShape;
	private AnimatedSprite player;
	private int playerDirection = -1;
	[Export] public float[] meterSpeed = {100,0,0};
	//speed button modifies this.
	// 0 - normal speed, 1 - fast, 2 - fastest
	private int speedBoost = 0;
	
	//Check if player is dead.
	private Vector2 deathPosition = new Vector2(0,0);
	private bool playerDead = false;
	private bool playerTimeout = false;
//

//Classic Mode
	private bool classicChangeSpeed = false;
	//In classic mode, the tick speed varies by difficulty.
	//Make ticker speed become closer together as score increases.
	private float[] tickerspeedMin = {150,200,200,200,200,200,250};
	private float[] tickerspeedMax = {250,400,500,600,700,800,900};
	
	private int[] speedChangeDifficulty = {2,5,15,20,30,500,0};
	//the last index is exclusively used for the bonus hit, this is an incredibly difficult critical hit to land.
	//So the players speed is capped off to make it a bit easier.
	
	//After 80 or so critical hits, range is maxed out.
	
	private float[] classicScaleMin = {200,100,50,25};
	private float[] classicScaleMax = {300,200,175,150};

	//Anything above 9999 disables the change difficulty index.
	private int[] scaleChangeDifficulty = {2,10,20,0};
	
	//If current score is above 30, do bonus one after every 10 scores.
	
	//After 500 rounds, make bonus have 5 options instead of 4.
	private float[] bonusScaleMin = {25,10,5,1,50};
	private float[] bonusScaleMax = {50,25,10,5,150};
	
//	private float[] hardSpeedMin = 1000;
//	private float[] hardSpeedMax = 1400;
//
//	private float[] hardScaleMin
	
	//This works slightly different, the bonus mode chooses a random scale and then
	//private float[] bonusChangeDifficulty
	
	
	private float[] bonusSpeedMin = {500,200,200,100,1000};
	private float[] bonusSpeedMax = {1000,500,325,175,1300};
	
	//How often to do bonus mode after a certain point, and which score to start doing em.
	private int bonusModeStart = 30;
	private int bonusModeFrequency = 15;
	

	private int scaleDifficultyIndex = 0;
	//Store's current speed of ticker based on randomized amount.
	private float currentSpeed = 0;
	
	//Speed index changes - 5,15,25,50 -> beyond 50 is randomized super difficult challenges. 
	//Determines the current difficulty and range of players speed
	private int speedDifficultyIndex = 0;
	
	private int speedIncrementCount = 0;
	//How often to change the player speed.
	private int speedChangeFrequency = 2;
	//How many hits to change the difficulty index.
	
	
	
	//how many rounds before changing the difficulty. - used only if there is only one difficulty.
	private float incrementCount = 0;
	//
	
//

//Time-Attack

	private float tickerSpeed = 100;
	
	//Use this when the player presses the speed button. This changes the speed to these values instead.
	private int changeSpeed = 400;
	private int changeSpeed2 = 400;
	
	//Init Settings
	
	//Don't spawn an enemy in the smaller numbers in hard-mode. (10-50)
	//Spawn more enemies in hard mode if the scale is right. 100-200
	
	//0 - easy 1 - medium 2 - hard
	
	
	private float[] timeScaleMin = {200,100,50,25,1};
	private float[] timeScaleMax = {300,200,200,150,150};

	private int timeDifficultyIndex = 0;
	//Anything above 9999 disables the change difficulty index.
	private int[] timeChangeDifficulty = {2,5,10,35,0};

	
	private int[] scoreSeconds = {20,10,5,3,2};
	private int[] scoreChangeDifficulty = {10,20,35,50,0};
	private int scoreSecondsIndex = 0;
	
//bonus mode stuff
	
	//minimum round to start bonus.
	private int bonusStart = 15;
	private int bonusChance = 5;
	
	//determines if we're in a bonus round.
	private bool timeBonusRound = false;
//

//Score-Attack
	

//GUI stuff
	//Get buttons
	private TouchScreenButton speedButton;
	private TouchScreenButton hitButton;
	private TouchScreenButton exitBtn;
	private TouchScreenButton resetBtn;
	private bool disablePress; //Makes sure no other buttons are pressed if something is loading (like a new scene or leaderboard).
	//Get score
	private long currentScore = 0;
	private long bestScore = 0;
	
	//Background
	private Node2D parallaxBackground;
	private float[] parallaxSpeeds = {1.56f,3.125f,6.25f,12.5f,25};
	
	//Get time
	private Timer frameTime; //Always runs.
	private Timer gameTime;
	//CountDown or CountUp
	private string timerSetting = "CountDown";
	//Set score attack number here as well, this initializes the timer.
	private string timeInit = "";
	private float timer = 0;
	
	private int seconds = 0;
	private int minutes = 0;
	private int hours = 0;
	
	private float startTime = 0;
	private float currentTime = 0;
	
//private Sprite backgroundLayer;
	private Label timeLeft;
	private Label criticalScore;
	private Label criticalBest;
//

	private float criticalExtents = 0;
	private float negativecriticalExtents = 0;
	private Vector2 criticalPosition;
	private Vector2 criticalScale;

//Particles
	private PackedScene collisionParticles;
	private Node2D particleSpawner;
	private PackedScene explosionParticles;
//

//Done initializing variables, lets play!
	
	
	
	public override void _Ready()
	{
		//Check if user is signed in, if not we remove the trophy button.
		var googlePlayer = GetNode("/root/leaderboardSystem");
		sceneTransition = GetNode<transitionTest>("/root/sceneSwitcher/transitionTest");
		
		var trophyBtn = GetNode("CanvasLayer/LeaderboardButton") as TouchScreenButton;
		googlePlayer.Call("CheckSignIn");
		
		if(!sceneTransition.isSignedIn)
			trophyBtn.Visible = false;
		
		pinkTexture1 = ResourceLoader.Load($"res://GFX_Folder/ParallaxB1.png") as Texture;
		pinkTexture2 = ResourceLoader.Load($"res://GFX_Folder/ParallaxB2.png") as Texture;
		pinkTexture3 = ResourceLoader.Load($"res://GFX_Folder/ParallaxB3.png") as Texture;
		pinkTexture4 = ResourceLoader.Load($"res://GFX_Folder/ParallaxB4.png") as Texture;
		pinkTexture5 = ResourceLoader.Load($"res://GFX_Folder/ParallaxB5.png") as Texture;

		greenTexture1 = ResourceLoader.Load($"res://GFX_Folder/ParallaxBG1.png") as Texture;
		greenTexture2 = ResourceLoader.Load($"res://GFX_Folder/ParallaxBG2.png") as Texture;
		greenTexture3 = ResourceLoader.Load($"res://GFX_Folder/ParallaxBG3.png") as Texture;
		greenTexture4 = ResourceLoader.Load($"res://GFX_Folder/ParallaxBG4.png") as Texture;
		greenTexture5 = ResourceLoader.Load($"res://GFX_Folder/ParallaxBG5.png") as Texture;

		redTexture1 = ResourceLoader.Load($"res://GFX_Folder/ParallaxC1.png") as Texture;
		redTexture2 = ResourceLoader.Load($"res://GFX_Folder/ParallaxC2.png") as Texture;
		redTexture3 = ResourceLoader.Load($"res://GFX_Folder/ParallaxC3.png") as Texture;
		redTexture4 = ResourceLoader.Load($"res://GFX_Folder/ParallaxC4.png") as Texture;
		redTexture5 = ResourceLoader.Load($"res://GFX_Folder/ParallaxC5.png") as Texture;

		blueTexture1 = ResourceLoader.Load($"res://GFX_Folder/ParallaxD1.png") as Texture;
		blueTexture2 = ResourceLoader.Load($"res://GFX_Folder/ParallaxD2.png") as Texture;
		blueTexture3 = ResourceLoader.Load($"res://GFX_Folder/ParallaxD3.png") as Texture;
		blueTexture4 = ResourceLoader.Load($"res://GFX_Folder/ParallaxD4.png") as Texture;
		blueTexture5 = ResourceLoader.Load($"res://GFX_Folder/ParallaxD5.png") as Texture;
		
		blackTexture1 = ResourceLoader.Load($"res://GFX_Folder/ParallaxF1.png") as Texture;
		blackTexture2 = ResourceLoader.Load($"res://GFX_Folder/ParallaxF2.png") as Texture;
		blackTexture3 = ResourceLoader.Load($"res://GFX_Folder/ParallaxF3.png") as Texture;
		blackTexture4 = ResourceLoader.Load($"res://GFX_Folder/ParallaxF4.png") as Texture;
		blackTexture5 = ResourceLoader.Load($"res://GFX_Folder/ParallaxF5.png") as Texture;
		
		brownTexture1 = ResourceLoader.Load($"res://GFX_Folder/ParallaxG1.png") as Texture;
		brownTexture2 = ResourceLoader.Load($"res://GFX_Folder/ParallaxG2.png") as Texture;
		brownTexture3 = ResourceLoader.Load($"res://GFX_Folder/ParallaxG3.png") as Texture;
		brownTexture4 = ResourceLoader.Load($"res://GFX_Folder/ParallaxG4.png") as Texture;
		brownTexture5 = ResourceLoader.Load($"res://GFX_Folder/ParallaxG5.png") as Texture;
			
		purpleTexture1 = ResourceLoader.Load($"res://GFX_Folder/ParallaxE1.png") as Texture;
		purpleTexture2 = ResourceLoader.Load($"res://GFX_Folder/ParallaxE2.png") as Texture;
		purpleTexture3 = ResourceLoader.Load($"res://GFX_Folder/ParallaxE3.png") as Texture;
		purpleTexture4 = ResourceLoader.Load($"res://GFX_Folder/ParallaxE4.png") as Texture;
		purpleTexture5 = ResourceLoader.Load($"res://GFX_Folder/ParallaxE5.png") as Texture;
		
	//Must cast in order to obtain access to variables.
	//var sceneManip = sceneCreator.GetNode<transitionTest>("transitionTest");
		hitButton = GetNode("CanvasLayer/Hit") as TouchScreenButton;
		speedButton = GetNode("CanvasLayer/SpeedBoost") as TouchScreenButton;
		exitBtn = GetNode("CanvasLayer/ExitToMenuBtn") as TouchScreenButton;
		resetBtn = GetNode("CanvasLayer/ResetBtn") as TouchScreenButton;
		
		
		//Particle spawning
		particleSpawner = GetNode("Particles") as Node2D;
		explosionParticles = (PackedScene)ResourceLoader.Load("res://Explosion.tscn");
		///Timer settings
		gameTime = GetNode("gameTimer") as Timer;
		gameTime.Start();
		
		frameTime = GetNode("frameCounter") as Timer;
		frameTime.Start();
		
		//Set timer based on game mode settings.
		if(sceneTransition.gameType == "timeAttack")
		{
			timeInit = sceneTransition.gameTimer;
			
			switch(timeInit)
			{
				case "tenMinute":
				minutes = 10;
				seconds = 0;
				break;
				
				case "fiveMinute":
				minutes = 5;
				seconds = 0;
				break;
				
				case "threeMinute":
				minutes = 3;
				seconds = 0;
				break;
				
				case "oneMinute":
				minutes = 1;
				seconds = 0;
				break;
				
				case "thirtySeconds":
				minutes = 0;
				seconds = 30;
				break;
				
				case "tenSeconds":
				minutes = 0;
				seconds = 10;
				break;
				
				case "fiveSeconds":
				minutes = 0;
				seconds = 5;
				break;
			}
		}
		else if(sceneTransition.gameType == "scoreAttack")
		{
			timeInit = scoreSeconds[scoreSecondsIndex].ToString();
			switch(timeInit)
			{
				case "20":
				minutes = 0;
				seconds = 20;
				break;
				
				case "10":
				minutes = 0;
				seconds = 10;
				break;
				
				case "5":
				minutes = 0;
				seconds = 5;
				break;
				
				case "3":
				minutes = 0;
				seconds = 3;
				break;
				
				case "2":
				minutes = 0;
				seconds = 2;
				break;
				
//				case "1":
//				minutes = 0;
//				gameTime.SetWaitTime(1.5f);
//				seconds = 1;
//				break;
			}
		}
		
		//Update best score to show the current best one.
		if(sceneTransition.gameType == "classicMode")
		{
			 bestScore = int.Parse(sceneTransition.saveDict["classicMode"].ToString());
		}
		else if(sceneTransition.gameType == "scoreAttack")
		{
			bestScore = int.Parse(sceneTransition.saveDict["scoreAttack"].ToString());
		}
		else if(sceneTransition.gameType == "timeAttack")
		{
			if(sceneTransition.gameTimer == "thirtySeconds")
				bestScore = int.Parse(sceneTransition.saveDict["timeAttack - thirtySeconds"].ToString());
			else if(sceneTransition.gameTimer == "oneMinute")
				bestScore = int.Parse(sceneTransition.saveDict["timeAttack - oneMinute"].ToString());
			else if(sceneTransition.gameTimer == "threeMinute")
				bestScore = int.Parse(sceneTransition.saveDict["timeAttack - threeMinute"].ToString());
			else if(sceneTransition.gameTimer == "fiveMinute")
				bestScore = int.Parse(sceneTransition.saveDict["timeAttack - fiveMinute"].ToString());
			else if(sceneTransition.gameTimer == "tenMinute")
				bestScore = int.Parse(sceneTransition.saveDict["timeAttack - tenMinute"].ToString());
		}
		
		
		//Initialize random seed.
		GD.Randomize();
		
		playerDirection = 1;

		//Random speed removed, uncomment this code to add it in again.
		
		//meterSpeed[0] += 1;
		player = GetNode("Ticker") as AnimatedSprite;
		//criticalHit = GetNode("CriticalArea") as Sprite;
		meterShape = GetNode<CollisionShape2D>("Bar/Area2D/BarCollider").GetShape() as RectangleShape2D;
		playerShape = GetNode<CollisionShape2D>("Ticker/Ticker_Area/Ticker_Collision").GetShape() as RectangleShape2D;
		meterBar = GetNode("Bar") as Sprite;
		meterSprite = GetNode("Meter") as Sprite;
		mainCamera = GetNode("meterCamera") as Camera2D;
		
		//GUI elements
		criticalScore = GetNode("CanvasLayer/PlayerScore") as Label;
		criticalBest = GetNode("CanvasLayer/Textbox/BestScore") as Label;
		timeLeft = GetNode("CanvasLayer/PlayerTime") as Label;
		DisplayTime();
		//
		
		//Classic Mode
			//Change GUI elements
		if(sceneTransition.gameType == "classicMode")
		{
			hitButton.Visible = false;
			speedButton.Visible = false;
			
			var removeTimeSprite = GetNode("CanvasLayer/timerSprite") as Sprite;
			removeTimeSprite.Visible = false;
			timeLeft.Visible = false;
			
			//Initialize speed.
			currentSpeed = (float)GD.RandRange(tickerspeedMin[speedDifficultyIndex],tickerspeedMax[speedDifficultyIndex]);
		}
		
		//Parallax
		parallaxBackground = GetNode("ParallaxNode") as Node2D;
		UpdateBG();
		foreach(Node2D i in parallaxBackground.GetChildren())
		{
			i.Position = new Vector2 (0,0);
		}
		
		meterBar.Position = new Vector2 (0,0);
		meterSprite.Position = new Vector2(meterBar.Position.x,meterBar.Position.y);
		//Pick random position based on bar's extents.
		float barLength = (meterShape.Extents.x + meterBar.Position.x);
		float negativebarLength = (meterBar.Position.x - meterShape.Extents.x);
		player.Position = new Vector2((float)GD.RandRange(negativebarLength,barLength),meterBar.Position.y);
		criticalArea = (PackedScene)ResourceLoader.Load("res://CriticalArea.tscn");
		criticalSet = GetNode("CriticalAreas") as Node2D;
		mainCamera.SetGlobalPosition(new Vector2 (meterSprite.GlobalPosition.x ,meterSprite.GlobalPosition.y));
		
		SpawnCriticalArea();
	}
	
		public override void _UnhandledInput(InputEvent @event)
	{
//Get button press
		if(@event is InputEventScreenTouch touchPress)
		{
			if(sceneTransition.gameType == "classicMode")
			{
				if(touchPress.Pressed)
				{
					deathPosition = player.Position;
					CriticalCheck();
				}
			}
		}
	}
	
	private void _on_LeaderboardButton_released()
	{
		sceneTransition.playButton();
		var googlePlayer = GetNode("/root/leaderboardSystem");
		//Call a GDScript function from C#
		
		if(sceneTransition.gameType == "classicMode")
		{
			googlePlayer.Call("Classic_Mode_Leaderboard", int.Parse(sceneTransition.saveDict["classicMode"].ToString()));
		}
		else if(sceneTransition.gameType == "scoreAttack")
		{
			googlePlayer.Call("Score_Attack_Leaderboard", int.Parse(sceneTransition.saveDict["scoreAttack"].ToString()));
		}
		else if(sceneTransition.gameType == "timeAttack")
		{
			if(sceneTransition.gameTimer == "thirtySeconds")
				googlePlayer.Call("Time_Attack_Thirty_Seconds_Leaderboard", int.Parse(sceneTransition.saveDict["timeAttack - thirtySeconds"].ToString()));
			else if(sceneTransition.gameTimer == "oneMinute")
				googlePlayer.Call("Time_Attack_One_Minute_Leaderboard", int.Parse(sceneTransition.saveDict["timeAttack - oneMinute"].ToString()));
			else if(sceneTransition.gameTimer == "threeMinute")
				googlePlayer.Call("Time_Attack_Three_Minute_Leaderboard", int.Parse(sceneTransition.saveDict["timeAttack - threeMinute"].ToString()));
			else if(sceneTransition.gameTimer == "fiveMinute")
				googlePlayer.Call("Time_Attack_Five_Minute_Leaderboard", int.Parse(sceneTransition.saveDict["timeAttack - fiveMinute"].ToString()));
			else if(sceneTransition.gameTimer == "tenMinute")
				googlePlayer.Call("Time_Attack_Ten_Minute_Leaderboard", int.Parse(sceneTransition.saveDict["timeAttack - tenMinute"].ToString()));
		}
	}
	
	private void _on_SpeedBoost2_pressed()
	{
		if(playerDead != true)
			speedBoost = 2;
	}


	private void _on_SpeedBoost2_released()
	{
		if(playerDead != true)
			speedBoost = 0;
	}
	
	private void _on_TouchScreenButton_pressed()
	{
		if(playerDead != true)
		speedBoost = 1;
	}

	private void _on_TouchScreenButton_released()
	{
		if(playerDead != true)
		speedBoost = 0;
	}
		
	private void _on_TouchScreenButton2_pressed()
	{
		deathPosition = player.Position;
		CriticalCheck();
	}
	
	private void _on_ExitToMenuBtn_released()
	{
		if(!disablePress)
		{
			sceneTransition.playButton();
			sceneTransition.SwitchScenes("res://Main_Menu.tscn");
			disablePress = true;
		}
	}


	private void _on_ResetBtn_released()
	{
	//Use autoloaded scene to switch scenes while the game is running.
	//Essentially this loads a scene that only does fading, and then un-fades to show the new scene.
		if(!disablePress)
		{
			sceneTransition.playButton();
			sceneTransition.SwitchScenes("res://Main_Game.tscn");
			disablePress = true;
		}
	}
	
	private void SpawnCriticalArea()
	{
		float randomScale = 0;
		//Round the critical area's position to nearest integer.
		float barLength = (meterShape.Extents.x + meterBar.Position.x);
		float negativebarLength = (meterBar.Position.x - meterShape.Extents.x);
		//Generate random scale after hitting the red thingy
		if(sceneTransition.gameType == "classicMode")
		{
			//Check if greater than certain amount and if divible by a certain frequency.
			//If bonus frequency is divisible by 20 then every 20 rounds is a bonus challenge.

			if((currentScore >= bonusModeStart) && (currentScore % bonusModeFrequency == 0))
			{
			//pick one of the size ranges in the min/max arrays, using RNG.
				long genRandom = 0;
				if(currentScore >= 500)
					genRandom = GD.Randi() % bonusScaleMin.Length;
				else
					genRandom = GD.Randi() % (bonusScaleMin.Length - 1);
				randomScale = (float)GD.RandRange(bonusScaleMin[genRandom], bonusScaleMax[genRandom]);
				currentSpeed = (float)GD.RandRange(bonusSpeedMin[genRandom],bonusSpeedMax[genRandom]);
				//Make speed change after bonus game.
				classicChangeSpeed = true;
			}
			else
			{
				randomScale = (float)GD.RandRange(classicScaleMin[scaleDifficultyIndex], classicScaleMax[scaleDifficultyIndex]);
			}
		}
		else if(sceneTransition.gameType == "timeAttack" || sceneTransition.gameType == "scoreAttack")
		{
			//Check if it's bonus round.
			//if(bonusSpawn)
			//{
			//randomScale = (float)GD.RandRange(timeScaleMin[timeDifficultyIndex], timeScaleMax[timeDifficultyIndex]);
			//}	
			randomScale = (float)GD.RandRange(timeScaleMin[timeDifficultyIndex], timeScaleMax[timeDifficultyIndex]);
//			}
		}
		
		//currentSpeed = 150;
		//randomScale = 1;
		
		//Use this as the range for position instead. (this leads to more reliable RNG.)
		
		//We only want to pick random numbers based on the scale of our critical hit area.
		var instanceRange = barLength - (randomScale/2);
		var negativeInstanceRange = negativebarLength + (randomScale/2);
		
		var randomPosition = GD.RandRange(negativeInstanceRange,instanceRange); //* ((double)barLength - (double)negativebarLength) + negativebarLength;
		//double randomScale = rand.NextDouble() * (endingScale[currentLevel] - startingScale[currentLevel]) + startingScale[currentLevel];
		
		criticalInstance = (Node2D)criticalArea.Instance();
		//add randomPosition
		criticalInstance.Position = new Vector2((float)randomPosition,meterBar.Position.y); 
		
		criticalInstance.Scale = new Vector2((float)randomScale,criticalInstance.Scale.y);

		var criticalShape = criticalInstance.GetNode<CollisionShape2D>("Critical_Area/thisArea/criticalCollider").GetShape() as RectangleShape2D;
		
		//Divide the scale in half and subtract from the maximum bar length, this puts the
		//critical area right at the edge of the bar.
		
		criticalScale = criticalInstance.Scale;
		criticalPosition = criticalInstance.Position;
		criticalExtents = ((criticalInstance.Scale.x/2) + criticalInstance.Position.x);
		negativecriticalExtents = (criticalInstance.Position.x - (criticalInstance.Scale.x/2));

		criticalSet.AddChild(criticalInstance);
		return;

	}

	//Only runs in time or score attack modes.
	private void SpawnBonusArea()
	{
		uint totalSpawn = GD.Randi() % 3 + 2;
		uint spawnAmount = totalSpawn;
		float randomScale = 0;
		//Round the critical area's position to nearest integer.
		float barLength = (meterShape.Extents.x + meterBar.Position.x);
		float negativebarLength = (meterBar.Position.x - meterShape.Extents.x);
		//Generate random scale after hitting the red thingy

		//how much leeway (so that critical items don't spawn in eachother.)
		var rangeOffset = 5;
		var instanceNegativeRange = 0.0f;
		var instancePositiveRange = 0.0f;
		
		//Check if score attack mode.
		if(sceneTransition.gameType == "scoreAttack" && seconds <= 3)
		{
			minutes = 0;
			seconds = 3;
		}
		if(totalSpawn == 2)
		{
			while(spawnAmount > 0)
			{
				//scale for each spawn.
				randomScale = (float)GD.RandRange(1, 10);
				
				if(spawnAmount == 2)
				{
					instancePositiveRange = barLength - (randomScale/2) - rangeOffset;
					instanceNegativeRange = 0 + (randomScale/2) + rangeOffset;
				}
				//Spawn left side
				else if(spawnAmount == 1)
				{
					instancePositiveRange = 0 - (randomScale/2) - rangeOffset;
					instanceNegativeRange = -barLength + (randomScale/2) + rangeOffset;
				}
						//We only want to pick random numbers based on the scale of our critical hit area.
				var instanceRange = barLength - (randomScale/2);
				var negativeInstanceRange = negativebarLength + (randomScale/2);
		
				//SpawnEnemy(negativeInstanceRange,instanceRange,randomScale);
						var randomPosition = GD.RandRange(instanceNegativeRange,instancePositiveRange); //* ((double)barLength - (double)negativebarLength) + negativebarLength;
				//double randomScale = rand.NextDouble() * (endingScale[currentLevel] - startingScale[currentLevel]) + startingScale[currentLevel];
				
				criticalInstance = (Node2D)criticalArea.Instance();
				//add randomPosition
				criticalInstance.Position = new Vector2((float)randomPosition,meterBar.Position.y); 
				var getSprite = criticalInstance.GetNode("Critical_Area") as Sprite;
				getSprite.Texture = (Texture)ResourceLoader.Load("res://GFX_Folder/Critical_Area2.png");
				criticalInstance.Scale = new Vector2((float)randomScale,criticalInstance.Scale.y);
				
				var criticalShape = criticalInstance.GetNode<CollisionShape2D>("Critical_Area/thisArea/criticalCollider").GetShape() as RectangleShape2D;
				
				//Divide the scale in half and subtract from the maximum bar length, this puts the
				//critical area right at the edge of the bar.
				
				criticalScale = criticalInstance.Scale;
				criticalPosition = criticalInstance.Position;
				criticalExtents = ((criticalInstance.Scale.x/2) + criticalInstance.Position.x);
				negativecriticalExtents = (criticalInstance.Position.x - (criticalInstance.Scale.x/2));
				criticalSet.AddChild(criticalInstance);
				spawnAmount --;
			}
		}
		else if(totalSpawn == 3)
		{
			while(spawnAmount > 0)
			{
				randomScale = (float)GD.RandRange(5, 30);
				//Spawn right
				if(spawnAmount == 3)
				{
					instancePositiveRange = barLength - (randomScale/2) - rangeOffset;
					instanceNegativeRange = (barLength/3) + (randomScale/2) + rangeOffset;
				}
				//Spawn middle
				else if(spawnAmount == 2)
				{
					instancePositiveRange = (barLength/3) - (randomScale/2) - rangeOffset;
					instanceNegativeRange = (-barLength/3) + (randomScale/2) + rangeOffset;
				}
				//Spawn left side
				else if(spawnAmount == 1)
				{
					instancePositiveRange = (-barLength/3) - (randomScale/2) - rangeOffset;
					instanceNegativeRange = -barLength + (randomScale/2) + rangeOffset;
				}
				var instanceRange = barLength - (randomScale/2);
				var negativeInstanceRange = negativebarLength + (randomScale/2);
		
						var randomPosition = GD.RandRange(instanceNegativeRange,instancePositiveRange); //* ((double)barLength - (double)negativebarLength) + negativebarLength;
				//double randomScale = rand.NextDouble() * (endingScale[currentLevel] - startingScale[currentLevel]) + startingScale[currentLevel];
				
				criticalInstance = (Node2D)criticalArea.Instance();
				//add randomPosition
				criticalInstance.Position = new Vector2((float)randomPosition,meterBar.Position.y); 
				var getSprite = criticalInstance.GetNode("Critical_Area") as Sprite;
				getSprite.Texture = (Texture)ResourceLoader.Load("res://GFX_Folder/Critical_Area2.png");
				criticalInstance.Scale = new Vector2((float)randomScale,criticalInstance.Scale.y);

				var criticalShape = criticalInstance.GetNode<CollisionShape2D>("Critical_Area/thisArea/criticalCollider").GetShape() as RectangleShape2D;
				
				//Divide the scale in half and subtract from the maximum bar length, this puts the
				//critical area right at the edge of the bar.
				
				criticalScale = criticalInstance.Scale;
				criticalPosition = criticalInstance.Position;
				criticalExtents = ((criticalInstance.Scale.x/2) + criticalInstance.Position.x);
				negativecriticalExtents = (criticalInstance.Position.x - (criticalInstance.Scale.x/2));
				criticalSet.AddChild(criticalInstance);
				spawnAmount --;
			}
		}
		else if(totalSpawn == 4)
		{
			while(spawnAmount > 0)
			{
				//for 4 spawning, we use even smaller scales.
				randomScale = (float)GD.RandRange(10,40);
				if(spawnAmount == 4)
				{
					instancePositiveRange = barLength - (randomScale/2) - rangeOffset;
					instanceNegativeRange = (barLength/4) + (randomScale/2) + rangeOffset;
				}
				else if(spawnAmount == 3)
				{
					instancePositiveRange = (barLength/4) - (randomScale/2) - rangeOffset;
					instanceNegativeRange = 0 + (randomScale/2) + rangeOffset;
				}
				//Spawn middle
				else if(spawnAmount == 2)
				{
					instancePositiveRange = 0 - (randomScale/2) - rangeOffset;
					instanceNegativeRange = (-barLength/4) + (randomScale/2) + rangeOffset;
				}
				//Spawn left side
				else if(spawnAmount == 1)
				{
					instancePositiveRange = (-barLength/4) - (randomScale/2) - rangeOffset;
					instanceNegativeRange = -barLength + (randomScale/2) + rangeOffset;
				}
				var instanceRange = barLength - (randomScale/2);
				var negativeInstanceRange = negativebarLength + (randomScale/2);
										var randomPosition = GD.RandRange(instanceNegativeRange,instancePositiveRange); //* ((double)barLength - (double)negativebarLength) + negativebarLength;
				//double randomScale = rand.NextDouble() * (endingScale[currentLevel] - startingScale[currentLevel]) + startingScale[currentLevel];
				
				criticalInstance = (Node2D)criticalArea.Instance();
				//add randomPosition
				var getSprite = criticalInstance.GetNode("Critical_Area") as Sprite;
				getSprite.Texture = (Texture)ResourceLoader.Load("res://GFX_Folder/Critical_Area2.png");
				criticalInstance.Position = new Vector2((float)randomPosition,meterBar.Position.y); 
				
				criticalInstance.Scale = new Vector2((float)randomScale,criticalInstance.Scale.y);

				var criticalShape = criticalInstance.GetNode<CollisionShape2D>("Critical_Area/thisArea/criticalCollider").GetShape() as RectangleShape2D;
				
				//Divide the scale in half and subtract from the maximum bar length, this puts the
				//critical area right at the edge of the bar.
				
				criticalScale = criticalInstance.Scale;
				criticalPosition = criticalInstance.Position;
				criticalExtents = ((criticalInstance.Scale.x/2) + criticalInstance.Position.x);
				negativecriticalExtents = (criticalInstance.Position.x - (criticalInstance.Scale.x/2));
				criticalSet.AddChild(criticalInstance);
				spawnAmount --;
			}
		}
	}
		
	public void CriticalCheck()
	{
		if(playerDead == true)
			return;
		var playerArea = player.GetNode("Ticker_Area") as Area2D; 
		var bodies = playerArea.GetOverlappingAreas();
		var isColliding = false;
		foreach(Node2D i in bodies)
		{
			var getParent = i.GetNode("../..") as Node2D;
			getParent.QueueFree();
			currentScore++;
			
			//Emit particles (explosion)
			float particleOffset = -7;
			Node2D explosionInstance = (Node2D)explosionParticles.Instance();
			//if time attack or score attack bonus round.
			if(timeBonusRound)
			{
				var getSprite = explosionInstance.GetNode("ExplosionAnimation") as AnimatedSprite;
				getSprite.Animation = "yellow_explosion";
			}
			explosionInstance.Position = new Vector2(player.Position.x,player.Position.y + particleOffset);
			particleSpawner.AddChild(explosionInstance);
			isColliding = true;
			sceneTransition.playHit();
			break;
		}
		if(!isColliding)
		{
			currentSpeed = 0;
			playerDead = true;
			player.Visible = false;
			return;
		}
		if(criticalSet.GetChildCount() > 1)
			return;
		
		if(sceneTransition.gameType == "classicMode")
		{
			if(scaleDifficultyIndex < scaleChangeDifficulty.Length - 1)
			{
				if(currentScore >= scaleChangeDifficulty[scaleDifficultyIndex])
				{
					scaleDifficultyIndex += 1;
				}
			}
			if(speedDifficultyIndex < speedChangeDifficulty.Length - 1)
			{
				if(currentScore >= speedChangeDifficulty[speedDifficultyIndex])
				{
					if(speedDifficultyIndex < speedChangeDifficulty.Length)
					speedDifficultyIndex += 1;
				}
			}
			//How often to change speeds, make sure to change speed after bonus mode.
			if(currentScore % speedChangeFrequency == 0 || classicChangeSpeed == true)
			{
				currentSpeed = (float)GD.RandRange(tickerspeedMin[speedDifficultyIndex],tickerspeedMax[speedDifficultyIndex]);
				classicChangeSpeed = false;
			}
		}
		else if(sceneTransition.gameType == "timeAttack")
		{

			//Prevents indexing out of bounds error.
			if(timeDifficultyIndex < timeChangeDifficulty.Length - 1)
			{
				if(currentScore >= timeChangeDifficulty[timeDifficultyIndex])
				{
					//if(timeDifficultyIndex < timeChangeDifficulty.Length)
					timeDifficultyIndex += 1;
				}
			}
		}
		else if(sceneTransition.gameType == "scoreAttack")
		{
			if(timeDifficultyIndex < timeChangeDifficulty.Length - 1)
			{
				if(currentScore >= timeChangeDifficulty[timeDifficultyIndex])
				{
					//if(timeDifficultyIndex < timeChangeDifficulty.Length)
					timeDifficultyIndex += 1;
				}
			}
			
			if(scoreSecondsIndex < scoreChangeDifficulty.Length - 1)
			{
				if(currentScore >= scoreChangeDifficulty[scoreSecondsIndex])
				{
					//if(timeDifficultyIndex < timeChangeDifficulty.Length)
					scoreSecondsIndex += 1;
				}
			}
			
			timeInit = scoreSeconds[scoreSecondsIndex].ToString();
			switch(timeInit)
			{
				case "20":
				minutes = 0;
				seconds = 20;
				break;
				
				case "10":
				minutes = 0;
				seconds = 10;
				break;
				
				case "5":
				minutes = 0;
				seconds = 5;
				break;
				
				case "3":
				minutes = 0;
				seconds = 3;
				break;
				
				case "2":
				minutes = 0;
				seconds = 2;
				break;
				
				//Technically this is 1 and a half seconds.
				case "1":
				minutes = 0;
				gameTime.SetWaitTime(1.5f);
				seconds = 1;
				break;
			}
			gameTime.Start();
			//Generate time.
			
		}
		
		incrementCount++;
		
		//Classic mode won't spawn extra enemies.
		if(sceneTransition.gameType == "classicMode")
		{
			SpawnCriticalArea();
			timeBonusRound = false;
			return;
		}
		else
		{
			if(currentScore >= bonusStart)
			{
				long checkBonus = GD.Randi() % bonusChance;
				if(checkBonus == 0)
				{
					SpawnBonusArea();
					timeBonusRound = true;
				}
				else
				{
					SpawnCriticalArea();
					timeBonusRound = false;
				}
			}
			else
			{
				SpawnCriticalArea();
				timeBonusRound = false;
			}
		}
	}
	//private bool detectButton;
	public override void _Process(float delta)
	{
		var trophyBtn = GetNode("CanvasLayer/LeaderboardButton") as TouchScreenButton;
		criticalScore.Text = $"{currentScore}";
		criticalBest.Text = $"{bestScore}";

		//Update position of the backgrounds, and multiply by delta time. 
		int x = 0;
		if(sceneTransition.saveDict["backgroundScrolling"].ToString() == "true")
		{
			foreach(Sprite i in parallaxBackground.GetChildren())
			{
				i.Position -= new Vector2 (parallaxSpeeds[x] * delta,0);
		//Texture width may vary depending on size of background.
				if(i.Position.x <= -i.Texture.GetWidth() / 4)
					i.Position = new Vector2(0,i.Position.y);
				x++;
			}
		}
		
		//Load intro buttons as well
		if(!sceneTransition.startGame)
			return;
		frameTime.WaitTime += 1;
		if(frameTime.WaitTime >= 1000)
			frameTime.WaitTime = 1;
		if(playerDead == true)
		{

			DisableThisButton(hitButton,"res://GFX_Folder/Action_Button1.png");
			DisableThisButton(speedButton,"res://GFX_Folder/UI_SpeedButton2 (Fast-Forward)-2.png");
						
			//every few seconds turn off player visibility.
//			if(frameTime.WaitTime % 25 == 0)
//				player.Visible = !player.Visible;
			return;
		}

		if(!sceneTransition.startGame)
		{
			//fade object to half transparency, change texture and make sure you can't press button.
			hitButton.SelfModulate = new Color(this.Modulate.r,this.Modulate.g,this.Modulate.b,0.5f);
			hitButton.SetBlockSignals(true);
			hitButton.Pressed = (Texture)ResourceLoader.Load("res://GFX_Folder/Action_Button1.png");

			speedButton.SelfModulate = new Color(this.Modulate.r,this.Modulate.g,this.Modulate.b,0.5f);
			speedButton.Pressed = (Texture)ResourceLoader.Load("res://GFX_Folder/UI_SpeedButton2 (Fast-Forward)-2.png");
				
			return;
		}
		else
		{
			
			EnableThisButton(hitButton,"res://GFX_Folder/Action_Button2.png");
			EnableThisButton(speedButton,"res://GFX_Folder/UI_SpeedButton2 (Fast-Forward)-3.png");
		}
		
		//Some classy shit.
			if(sceneTransition.gameType == "classicMode")
			{
				//Declare timer sprite and do some stuff with it, like delete it.
				var removeTimeSprite = GetNode("CanvasLayer/timerSprite") as Sprite;
				removeTimeSprite.Visible = false;
				timeLeft.Visible = false;
				return;
			}
		//
		if(timerSetting == "CountDown")
		{
			if(gameTime.GetTimeLeft() == 0)
			{
				seconds--;
				gameTime.Start();
			}

			if(minutes == 0 && seconds == 0)
			{
			//end game here
				playerDead = true;
				deathPosition = player.Position;
				player.Visible = false;
				playerTimeout = true;
				//return;
			}
			
			if(seconds < 0)
			{
				seconds = 59; 
				minutes -= 1;
			}
		}
		DisplayTime();
	}

	private void DisplayTime()
	{
		string minutesToString = $"{minutes}";
		if(minutes <= 9 && minutes >= 0)
			minutesToString = $"0{minutes}";

		string secondsToString = $"{seconds}";
		if(seconds <= 9 && seconds >= 0)
			secondsToString = $"0{seconds}";

		timeLeft.Text = $"{minutesToString}:{secondsToString}";
	}
	
	private void DisableThisButton(TouchScreenButton button,string changeGFX)
	{
		button.SelfModulate = new Color(this.Modulate.r,this.Modulate.g,this.Modulate.b,0.5f);
		button.SetBlockSignals(true);
		button.Pressed = (Texture)ResourceLoader.Load(changeGFX);
	}
	
	private void EnableThisButton(TouchScreenButton button,string changeGFX)
	{
		button.SelfModulate = new Color(this.Modulate.r,this.Modulate.g,this.Modulate.b,1f);
		button.SetBlockSignals(false);
		button.Pressed = (Texture)ResourceLoader.Load(changeGFX);
	}

	private void DeathRoutine()
	{
		
		
		//Only run this once on death.
		if(!saveCheck)
		{
			//Play death sound effect.
			sceneTransition.playDead();
			saveCheck = true;

			if(currentScore > bestScore)
			{
				//If score is greater, update it and save the game.
				bestScore = currentScore;
				if(sceneTransition.gameType == "classicMode")
				{
					sceneTransition.saveDict["classicMode"] = bestScore.ToString();
				}
				else if(sceneTransition.gameType == "scoreAttack")
				{
					sceneTransition.saveDict["scoreAttack"] = bestScore.ToString();
				}
				else if(sceneTransition.gameType == "timeAttack")
				{
					if(sceneTransition.gameTimer == "thirtySeconds")
						sceneTransition.saveDict["timeAttack - thirtySeconds"] = bestScore.ToString();
					else if(sceneTransition.gameTimer == "oneMinute")
						sceneTransition.saveDict["timeAttack - oneMinute"] = bestScore.ToString();
					else if(sceneTransition.gameTimer == "threeMinute")
						sceneTransition.saveDict["timeAttack - threeMinute"] = bestScore.ToString();
					else if(sceneTransition.gameTimer == "fiveMinute")
						sceneTransition.saveDict["timeAttack - fiveMinute"] = bestScore.ToString();
					else if(sceneTransition.gameTimer == "tenMinute")
						sceneTransition.saveDict["timeAttack - tenMinute"] = bestScore.ToString();
				}
				sceneTransition.SaveGame();
			}
		}
		
		//Display timeout label if timer is equal to 0.
		var timeoutText = GetNode("CanvasLayer/Textbox/TimeoutLabel") as Label;
		if(!playerTimeout)
			timeoutText.Visible = false;
		
		//Move touch buttons
		bool moveMenuButtons = true;
		bool moveActionButtons = true;
		bool moveTrophy = true;
		Vector2 btnSpeed = new Vector2(5,5);
		
		var trophyBtn = GetNode("CanvasLayer/LeaderboardButton") as TouchScreenButton;
		var exitCheck = GetNode("CanvasLayer/IconMovePositions/ExitBtnPos") as Position2D;
		var resetCheck = GetNode("CanvasLayer/IconMovePositions/ResetBtnPos") as Position2D;
		var hitCheck = GetNode("CanvasLayer/IconMovePositions/HitBtnPos") as Position2D;
		var speedCheck = GetNode("CanvasLayer/IconMovePositions/SpeedBtnPos") as Position2D;
		var trophyCheck = GetNode("CanvasLayer/IconMovePositions/TrophyBtnPos") as Position2D;
		
		if(moveTrophy)
		{
			trophyBtn.Position -= new Vector2(0,btnSpeed.y);
		}
		
		if(trophyBtn.Position.y <= trophyCheck.Position.y)
		{
			moveTrophy = false; 
			trophyBtn.Position = new Vector2(trophyCheck.Position.x,trophyCheck.Position.y);

		}
		
		if(moveMenuButtons)
		{
			exitBtn.Position += new Vector2(btnSpeed.x,0);
			resetBtn.Position -= new Vector2(btnSpeed.x,0);
		}
		
		if(exitBtn.Position.x >= exitCheck.Position.x)
		{
			moveMenuButtons = false; 
			exitBtn.Position = new Vector2(exitCheck.Position.x,exitCheck.Position.y);
			resetBtn.Position = new Vector2(resetCheck.Position.x,resetCheck.Position.y);
		}
		
		if(moveActionButtons)
		{
			hitButton.Position += new Vector2(0,btnSpeed.y);
			speedButton.Position += new Vector2(0,btnSpeed.y);
		}
		
		if(speedButton.Position.y >= speedCheck.Position.y)
		{
			moveActionButtons = false; 
			speedButton.Position = new Vector2(speedCheck.Position.x,speedCheck.Position.y);
			hitButton.Position = new Vector2(hitCheck.Position.x,hitCheck.Position.y);
		}
		
		
		//Move textbox to display top score.
		
		bool moveText = true;
		Vector2 textSpeed = new Vector2(0,5); 
		
		var text = GetNode("CanvasLayer/Textbox") as Sprite;
		var textEndPos = GetNode("CanvasLayer/TextboxStop") as Position2D;
		
		//If within a certain range, snap to position.
		
		if(moveText)
			text.Position += textSpeed;
		
		if(text.Position.y >= textEndPos.Position.y)
		{
			moveText = false; 
			text.Position = new Vector2(textEndPos.Position.x,textEndPos.Position.y);
		}
	}

	public override void _PhysicsProcess(float delta)
	{
				//Get user input - if space is pressed (or touch input)
		bool detectButton = Input.IsActionJustPressed("Hit");
		if(detectButton == true)
		{
			deathPosition = player.Position;
			CriticalCheck();
			return;	
		}

		float playerExtents = playerShape.Extents.x + player.Position.x;
		float negativePlayerExtents = player.Position.x - playerShape.Extents.x;
		
		float barLength = meterShape.Extents.x + meterBar.Position.x;
		float negativebarLength = meterBar.Position.x - meterShape.Extents.x;
		if(playerDead == true)
		{
			currentSpeed = 0;
			player.Position = deathPosition;
			DeathRoutine();
			return;
		}

		if(sceneTransition.gameType == "scoreAttack" || sceneTransition.gameType == "timeAttack")
		{
			if(speedBoost == 0)
			player.Position += new Vector2(((float)tickerSpeed * playerDirection * delta),0);
			else if(speedBoost == 1)
			player.Position += new Vector2(((float)(changeSpeed) * playerDirection * delta),0);
			else if(speedBoost == 2)
			player.Position += new Vector2(((float)(changeSpeed2) * playerDirection * delta),0);
		}
		else
		{
			player.Position += new Vector2(((float)currentSpeed * playerDirection * delta),0);
		}

		if(player.Position.x >= barLength || player.Position.x <= negativebarLength)
		{
			//Upon contact set player equal to position then flip direction (like turning a sprite around or doing grount contact)				
			playerDirection *= -1;
			if(playerDirection == -1)
			player.Position = new Vector2(barLength,player.Position.y);
			else 
			player.Position = new Vector2(negativebarLength,player.Position.y);
		}
		
	}
	
		private void UpdateBG()
	{
		var five = (Sprite)parallaxBackground.GetChild(4);
		var four = (Sprite)parallaxBackground.GetChild(3);
		var three = (Sprite)parallaxBackground.GetChild(2);
		var two = (Sprite)parallaxBackground.GetChild(1);
		var one = (Sprite)parallaxBackground.GetChild(0);
		
		switch(sceneTransition.saveDict["backgroundColor"].ToString())
		{
			case"red":
			one.Texture = redTexture5;
			two.Texture = redTexture4;
			three.Texture = redTexture3;
			four.Texture = redTexture2;
			five.Texture = redTexture1;
			break;
			case"blue":
			one.Texture = blueTexture5;
			two.Texture = blueTexture4;
			three.Texture = blueTexture3;
			four.Texture = blueTexture2;
			five.Texture = blueTexture1;
			break;
			case"brown":
			one.Texture = brownTexture5;
			two.Texture = brownTexture4;
			three.Texture = brownTexture3;
			four.Texture = brownTexture2;
			five.Texture = brownTexture1;
			break;
			case"black":
			one.Texture = blackTexture5;
			two.Texture = blackTexture4;
			three.Texture = blackTexture3;
			four.Texture = blackTexture2;
			five.Texture = blackTexture1;
			break;
			case"pink":
			one.Texture = pinkTexture5;
			two.Texture = pinkTexture4;
			three.Texture = pinkTexture3;
			four.Texture = pinkTexture2;
			five.Texture = pinkTexture1;
			break;
			case"purple":
			one.Texture = purpleTexture5;
			two.Texture = purpleTexture4;
			three.Texture = purpleTexture3;
			four.Texture = purpleTexture2;
			five.Texture = purpleTexture1;
			break;
			case"green":
			one.Texture = greenTexture5;
			two.Texture = greenTexture4;
			three.Texture = greenTexture3;
			four.Texture = greenTexture2;
			five.Texture = greenTexture1;
			break;
			
			default:
			break;
		}
	}
	
	//Detect if game is the main displayed window. (kill player if not.)
	public override void _Notification(int check)
	{
		if(check == MainLoop.NotificationWmFocusOut)
		{
			deathPosition = player.Position;
			playerDead = true;
		}
	}
}
