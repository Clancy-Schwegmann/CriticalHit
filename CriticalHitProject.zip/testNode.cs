using Godot;
using System;

public class testNode : Node2D
{
	// Declare member variables here. Examples:
	// private int a = 2;
	// private string b = "text";
	public bool collisionFound = false;
	
	public Vector2 getTouchPos = new Vector2(0,0);
	public Vector2 getRectPos = new Vector2(0,0);
	public Rect2 defineRect;
	public Vector2 rectScale = new Vector2(10,10);
	
	//Rectangle attributes, used for collision.
	public float rectLeft;
	public float rectRight;
	public float rectUp;
	public float rectDown;
	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
		
	}

	public override void _Draw()
	{
		Color rectColor = new Color(1,0,0);
		DrawRect(defineRect,rectColor);
	// Your draw commands here
	}

//Old-way

	public override void _UnhandledInput(InputEvent @event)
	{
//Get button press
		if(@event is InputEventScreenTouch touchPress)
		{

			if(touchPress.Pressed)
			{
				getTouchPos = new Vector2(touchPress.Position.x, touchPress.Position.y);
				getRectPos = new Vector2(touchPress.Position.x - (rectScale.x/2), touchPress.Position.y - (rectScale.y/2));
				//Now make rect
				defineRect = new Rect2(getRectPos,rectScale); 
				Update();

				//Check collisions now.
				//Up-left is gotten by default, since that's where touch-press is.
				rectUp = getRectPos.y;
				rectLeft = getRectPos.x;
				rectRight = getRectPos.x + rectScale.x;
				rectDown = getRectPos.y + rectScale.y;

				GD.Print(GetViewport().GetMousePosition());
				GD.Print(getTouchPos);

				var getButton = GetNode("thisExitButton") as AnimatedSprite;
				var getShape = getButton.GetNode<CollisionShape2D>("area/collision").GetShape() as RectangleShape2D;

				var buttonUp = getButton.Position.y - (getShape.Extents.y/2);
				var buttonDown = getButton.Position.y + (getShape.Extents.y/2);
				var buttonRight = getButton.Position.x + (getShape.Extents.x/2);
				var buttonLeft = getButton.Position.x - (getShape.Extents.x/2);
//				if(rectDown > buttonUp && rectUp < buttonDown)
//					GD.Print("collisionFound");

				if((rectRight > buttonLeft && rectLeft < buttonRight) && (rectDown > buttonUp && rectUp < buttonDown)) //&& rectLeft < buttonRight)
				{
					collisionFound = true;
				}	
				else
					collisionFound = false;

				//	return;

				GD.Print(rectLeft, buttonLeft,rectRight, buttonRight);
			}
			else
			{
				collisionFound = false;
			}
		}
	}

//  // Called every frame. 'delta' is the elapsed time since the previous frame.
  public override void _Process(float delta)
  {
	  var getButton = GetNode("thisExitButton") as AnimatedSprite;
	if(collisionFound)
		getButton.Frame = 1;
	else
		getButton.Frame = 0;
  }
}
