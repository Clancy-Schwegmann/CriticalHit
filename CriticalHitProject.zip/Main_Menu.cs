using Godot;
using System;

public class Main_Menu : Node2D
{
	//Random crap
		private Texture pinkTexture1;
		private Texture pinkTexture2;
		private Texture pinkTexture3;
		private Texture pinkTexture4;
		private Texture pinkTexture5;
		
		private Texture greenTexture1;
		private Texture greenTexture2;
		private Texture greenTexture3;
		private Texture greenTexture4;
		private Texture greenTexture5;
		
		private Texture brownTexture1;
		private Texture brownTexture2;
		private Texture brownTexture3;
		private Texture brownTexture4;
		private Texture brownTexture5;
		
		private Texture blackTexture1;
		private Texture blackTexture2;
		private Texture blackTexture3;
		private Texture blackTexture4;
		private Texture blackTexture5;
		
		private Texture purpleTexture1;
		private Texture purpleTexture2;
		private Texture purpleTexture3;
		private Texture purpleTexture4;
		private Texture purpleTexture5;
		
		private Texture blueTexture1;
		private Texture blueTexture2;
		private Texture blueTexture3;
		private Texture blueTexture4;
		private Texture blueTexture5;
		
		private Texture redTexture1;
		private Texture redTexture2;
		private Texture redTexture3;
		private Texture redTexture4;
		private Texture redTexture5;
		
		private Texture offTexture;
		private Texture onTexture;
		
		private Texture pauseTexture;
		private Texture playTexture;
		private Texture loopOnTexture;
		private Texture loopOffTexture;
	//
	
	// Positional stuff
		private TouchScreenButton settingsWin;
	
		private Position2D initSettingsPos;
		private Position2D finalSettingsPos;
		private Position2D currentSettingsPos;
		private Position2D currentTimePosition;
		private Position2D currentGamePosition;
		private Position2D gamePos1;
		private Position2D timePos1;
		private Position2D timePos2;
	//
	
	//Credits
		private Node2D creditsMovement;
		private Position2D centeredPosition;
		private AnimationPlayer creditsPlayer;
		private VBoxContainer hideText;
		
		private AnimatedSprite titleSprite;
		//How much to displace the sprite, from initial position.
		private float titleSpriteOffset = -100;
		private Vector2 oldTitlePos;
		private Vector2 newTitlePos;
		private TouchScreenButton backBtn;
	//
	
	//Settings
		private Node2D settings_Control;
		private Control settingsItems;
		private Sprite selectBG;
		private AnimationPlayer settingsPlayer;
		//Controls when to move the BG thingy.
		private string moveBGChanger = "";
		private TouchScreenButton bgChangeButton1;
		private TouchScreenButton bgChangeButton2;
		private TouchScreenButton bgChangeButton3;
		private TouchScreenButton bgChangeButton4;
		private TouchScreenButton bgChangeButton5;
		private TouchScreenButton bgChangeButton6;
		private TouchScreenButton bgChangeButton7;
		
		private TouchScreenButton muteMusicBtn;
		private TouchScreenButton muteSoundBtn;
		private TouchScreenButton disableScrollBtn;
		private TouchScreenButton playBtn;
		private TouchScreenButton loopBtn;
		
		private float bgChangerSpeed = 5;
		private float timeToMove = 0;
		private Vector2 currentChangerPos = new Vector2(0,0);
		private Label songLabel;
	//
	
	//Background
		private Node2D parallaxBackground;
		private float[] parallaxSpeeds = {1.56f,3.125f,6.25f,12.5f,25};
	//
	
	//Make button press do nothing.
		private bool disablePress;
	
	//Autoloaded script, used for transitioning scenes.
		public transitionTest sceneTransition;
		private int moveStep = 0;
		private string menuMovement = "";
		private string settingsMovement = "";
		private string currentScreen = "Select Game";
		private float menuMovementSpeed = 500;
	public override void _Ready()
	{
		//Load stuff and memorize headphone settings.

		pinkTexture1 = ResourceLoader.Load($"res://GFX_Folder/ParallaxB1.png") as Texture;
		pinkTexture2 = ResourceLoader.Load($"res://GFX_Folder/ParallaxB2.png") as Texture;
		pinkTexture3 = ResourceLoader.Load($"res://GFX_Folder/ParallaxB3.png") as Texture;
		pinkTexture4 = ResourceLoader.Load($"res://GFX_Folder/ParallaxB4.png") as Texture;
		pinkTexture5 = ResourceLoader.Load($"res://GFX_Folder/ParallaxB5.png") as Texture;

		greenTexture1 = ResourceLoader.Load($"res://GFX_Folder/ParallaxBG1.png") as Texture;
		greenTexture2 = ResourceLoader.Load($"res://GFX_Folder/ParallaxBG2.png") as Texture;
		greenTexture3 = ResourceLoader.Load($"res://GFX_Folder/ParallaxBG3.png") as Texture;
		greenTexture4 = ResourceLoader.Load($"res://GFX_Folder/ParallaxBG4.png") as Texture;
		greenTexture5 = ResourceLoader.Load($"res://GFX_Folder/ParallaxBG5.png") as Texture;

		redTexture1 = ResourceLoader.Load($"res://GFX_Folder/ParallaxC1.png") as Texture;
		redTexture2 = ResourceLoader.Load($"res://GFX_Folder/ParallaxC2.png") as Texture;
		redTexture3 = ResourceLoader.Load($"res://GFX_Folder/ParallaxC3.png") as Texture;
		redTexture4 = ResourceLoader.Load($"res://GFX_Folder/ParallaxC4.png") as Texture;
		redTexture5 = ResourceLoader.Load($"res://GFX_Folder/ParallaxC5.png") as Texture;

		blueTexture1 = ResourceLoader.Load($"res://GFX_Folder/ParallaxD1.png") as Texture;
		blueTexture2 = ResourceLoader.Load($"res://GFX_Folder/ParallaxD2.png") as Texture;
		blueTexture3 = ResourceLoader.Load($"res://GFX_Folder/ParallaxD3.png") as Texture;
		blueTexture4 = ResourceLoader.Load($"res://GFX_Folder/ParallaxD4.png") as Texture;
		blueTexture5 = ResourceLoader.Load($"res://GFX_Folder/ParallaxD5.png") as Texture;
		
		blackTexture1 = ResourceLoader.Load($"res://GFX_Folder/ParallaxF1.png") as Texture;
		blackTexture2 = ResourceLoader.Load($"res://GFX_Folder/ParallaxF2.png") as Texture;
		blackTexture3 = ResourceLoader.Load($"res://GFX_Folder/ParallaxF3.png") as Texture;
		blackTexture4 = ResourceLoader.Load($"res://GFX_Folder/ParallaxF4.png") as Texture;
		blackTexture5 = ResourceLoader.Load($"res://GFX_Folder/ParallaxF5.png") as Texture;
		
		brownTexture1 = ResourceLoader.Load($"res://GFX_Folder/ParallaxG1.png") as Texture;
		brownTexture2 = ResourceLoader.Load($"res://GFX_Folder/ParallaxG2.png") as Texture;
		brownTexture3 = ResourceLoader.Load($"res://GFX_Folder/ParallaxG3.png") as Texture;
		brownTexture4 = ResourceLoader.Load($"res://GFX_Folder/ParallaxG4.png") as Texture;
		brownTexture5 = ResourceLoader.Load($"res://GFX_Folder/ParallaxG5.png") as Texture;
			
		purpleTexture1 = ResourceLoader.Load($"res://GFX_Folder/ParallaxE1.png") as Texture;
		purpleTexture2 = ResourceLoader.Load($"res://GFX_Folder/ParallaxE2.png") as Texture;
		purpleTexture3 = ResourceLoader.Load($"res://GFX_Folder/ParallaxE3.png") as Texture;
		purpleTexture4 = ResourceLoader.Load($"res://GFX_Folder/ParallaxE4.png") as Texture;
		purpleTexture5 = ResourceLoader.Load($"res://GFX_Folder/ParallaxE5.png") as Texture;
		
		offTexture = ResourceLoader.Load($"res://GFX_Folder/Checkbox1.png") as Texture;
		onTexture = ResourceLoader.Load($"res://GFX_Folder/Checkbox6.png") as Texture;
		
		pauseTexture = ResourceLoader.Load($"res://GFX_Folder/PauseButton_16x16.png") as Texture;
		playTexture = ResourceLoader.Load($"res://GFX_Folder/PauseButton_16x17.png") as Texture;
			
		loopOnTexture = ResourceLoader.Load($"res://GFX_Folder/LoopSong_16x17.png") as Texture;
		loopOffTexture = ResourceLoader.Load($"res://GFX_Folder/LoopSong_16x16.png") as Texture;
		
		//Declare stuff
		sceneTransition = GetNode<transitionTest>("/root/sceneSwitcher/transitionTest");
		sceneTransition.LoadGame();

		//Positions
		settingsWin = GetNode("CanvasLayer/SettingsNode/SettingsWindow") as TouchScreenButton;
	
		initSettingsPos = GetNode("CanvasLayer/SettingsNode/InitSettingsPosition") as Position2D;
		finalSettingsPos = GetNode("CanvasLayer/SettingsNode/SettingsPosition") as Position2D;
		currentSettingsPos = GetNode("CanvasLayer/SettingsNode/CurrentSettingsPosition") as Position2D;
		currentTimePosition = GetNode("CanvasLayer/TimeSettings/CurrentTimePosition") as Position2D;
		currentGamePosition = GetNode("CanvasLayer/GameSettings/CurrentGamePosition") as Position2D;
		timePos1 = GetNode("CanvasLayer/TimePosition1") as Position2D;
		timePos2 = GetNode("CanvasLayer/TimePosition2") as Position2D;
		gamePos1 = GetNode("CanvasLayer/GameSettings/GameSettingsPosition") as Position2D;
		
		currentTimePosition.Position = new Vector2(timePos1.Position.x,timePos1.Position.y);
		currentGamePosition.Position = new Vector2(gamePos1.Position.x,gamePos1.Position.y);
		initSettingsPos.Position = new Vector2(settingsWin.Position.x,settingsWin.Position.y);
		currentSettingsPos.Position = new Vector2(settingsWin.Position.x,settingsWin.Position.y);

				
		//Credits stuff

		creditsPlayer = GetNode("CanvasLayer/CreditsControl/CreditsAnimation") as AnimationPlayer;
		creditsMovement = GetNode("CanvasLayer/CreditsControl") as Node2D;
		centeredPosition = GetNode("CanvasLayer/CenterPosition") as Position2D;
		
		hideText = GetNode("CanvasLayer/CreditsControl/CreditsLabels") as VBoxContainer;

		//get credits sprite and positional data.
		titleSprite = GetNode("CanvasLayer/TitleControl/TitleSprite") as AnimatedSprite;
		oldTitlePos = new Vector2(titleSprite.Position.x,titleSprite.Position.y);//(titleSprite.Position.x,titleSprite.Position.y);
		newTitlePos = new Vector2(titleSprite.Position.x,titleSprite.Position.y + titleSpriteOffset);
		backBtn = GetNode("CanvasLayer/CreditsControl/BackButton") as TouchScreenButton;
		backBtn.Modulate = new Color(this.Modulate.r,this.Modulate.g,this.Modulate.b,0);
		hideText.Modulate = new Color(this.Modulate.r,this.Modulate.g,this.Modulate.b,0);
		
		//Settings
		settingsPlayer = GetNode("CanvasLayer/SettingsControl/SettingsAnimate") as AnimationPlayer;
		songLabel = GetNode("CanvasLayer/SettingsControl/SettingsItems/songLbl") as Label;
		settings_Control = GetNode("CanvasLayer/SettingsControl") as Node2D;
		selectBG = GetNode("CanvasLayer/SettingsControl/SettingsItems/BGChanger") as Sprite;
		settingsItems = GetNode("CanvasLayer/SettingsControl/SettingsItems") as Control;
		
		bgChangeButton1 = GetNode("CanvasLayer/SettingsControl/SettingsItems/SettingsButtons/BGChange1") as TouchScreenButton;
		bgChangeButton2 = GetNode("CanvasLayer/SettingsControl/SettingsItems/SettingsButtons/BGChange2") as TouchScreenButton;
		bgChangeButton3 = GetNode("CanvasLayer/SettingsControl/SettingsItems/SettingsButtons/BGChange3") as TouchScreenButton;
		bgChangeButton4 = GetNode("CanvasLayer/SettingsControl/SettingsItems/SettingsButtons/BGChange4") as TouchScreenButton;
		bgChangeButton5 = GetNode("CanvasLayer/SettingsControl/SettingsItems/SettingsButtons/BGChange5") as TouchScreenButton;
		bgChangeButton6 = GetNode("CanvasLayer/SettingsControl/SettingsItems/SettingsButtons/BGChange6") as TouchScreenButton;
		bgChangeButton7 = GetNode("CanvasLayer/SettingsControl/SettingsItems/SettingsButtons/BGChange7") as TouchScreenButton;
		
		muteMusicBtn = GetNode("CanvasLayer/SettingsControl/SettingsItems/SettingsButtons/MuteMusicBtn") as TouchScreenButton;
		muteSoundBtn = GetNode("CanvasLayer/SettingsControl/SettingsItems/SettingsButtons/MuteSoundBtn") as TouchScreenButton;
		disableScrollBtn = GetNode("CanvasLayer/SettingsControl/SettingsItems/SettingsButtons/DisableScrollBtn") as TouchScreenButton;
		
		playBtn = GetNode("CanvasLayer/SettingsControl/SettingsItems/SettingsButtons/PlaySongBtn") as TouchScreenButton;
		loopBtn = GetNode("CanvasLayer/SettingsControl/SettingsItems/SettingsButtons/LoopSongBtn") as TouchScreenButton;
		
		if(sceneTransition.saveDict["backgroundScrolling"].ToString() == "false")
			disableScrollBtn.Normal = onTexture;
		else
			disableScrollBtn.Normal = offTexture;
			
		if(sceneTransition.saveDict["muteMusic"].ToString() == "false")
		{
			muteMusicBtn.Normal = onTexture;
			var busMusicIndex = AudioServer.GetBusIndex("Music");
			AudioServer.SetBusMute(busMusicIndex, true);
		}
		else
			muteMusicBtn.Normal = offTexture;
			
		if(sceneTransition.saveDict["muteSound"].ToString() == "false")
		{
			muteSoundBtn.Normal = onTexture;
			var busSoundIndex = AudioServer.GetBusIndex("SFX");
			AudioServer.SetBusMute(busSoundIndex, true);
		}
		else
			muteSoundBtn.Normal = offTexture;
			
		if(sceneTransition.saveDict["favoriteSong"].ToString() != "")
			sceneTransition.isLooping = true;
		else
			sceneTransition.isLooping = false;
			
		settingsItems.Modulate = new Color(settingsItems.Modulate.r,settingsItems.Modulate.g,settingsItems.Modulate.b,0);
		//
		
		
		parallaxBackground = GetNode("ParallaxNode") as Node2D;
		//Load BG Data here.
		UpdateBG();
		//
		
		//Parallax
		foreach(Node2D i in parallaxBackground.GetChildren())
		{
			i.Position = new Vector2 (0,0);
		}
		
		//Play music
		if(!sceneTransition.initSong)
			sceneTransition.songStart();
	}

private void vectorDifference(Vector2 firstVec,Vector2 secondVec)
{
	var findDifference = Math.Abs(firstVec.x - secondVec.x);
	if(findDifference <= 1)
	{
		moveBGChanger = "";
		selectBG.Position = secondVec;
	}
}

private void DisplaySongInfo()
{
	if(sceneTransition.songQueue[sceneTransition.currentSong] == "Storm Trap")
	{
		songLabel.Text = "Storm Trap\nby Giants' Nest";
	}
	else if(sceneTransition.songQueue[sceneTransition.currentSong] == "Evening Mood")
	{
		songLabel.Text = "Evening Mood\nby Sum Wave";
	}
	else if(sceneTransition.songQueue[sceneTransition.currentSong] == "Zero One")
	{
		songLabel.Text = "Zero One\nby Young Community";
	}
	else if(sceneTransition.songQueue[sceneTransition.currentSong] == "Down the Well")
	{
		songLabel.Text = "Down the Well\nby Out Line";
	}
	else if(sceneTransition.songQueue[sceneTransition.currentSong] == "Gambling Bonnie")
	{
		songLabel.Text = "Gambling Bonnie\nby Harvio";
	}
	else if(sceneTransition.songQueue[sceneTransition.currentSong] == "Ripples on the Water")
	{
		songLabel.Text = "Ripples on the Water\nby Nebulae";
	}
}

//  // Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _PhysicsProcess(float delta)
	{
		
		DisplaySongInfo();
		if(sceneTransition.isPaused)
			playBtn.Normal = playTexture;
		else
			playBtn.Normal = pauseTexture;
			
		if(sceneTransition.isLooping)
			loopBtn.Normal = loopOnTexture;
		else
			loopBtn.Normal = loopOffTexture;
			
		
		

		var movegameItems = GetNode("CanvasLayer/GameSettings") as Node2D;
		var movetimeItems = GetNode("CanvasLayer/TimeSettings") as Node2D;
		var moveSettingsItems = GetNode("CanvasLayer/SettingsNode") as Node2D;
		
		var gameItemsPos = GetNode("CanvasLayer/GameSettings/GameSettingsPosition") as Position2D;
		var timeItemsPos = GetNode("CanvasLayer/TimeSettings/TimeSettingsPosition") as Position2D;
		var settingsItemsPos = GetNode("CanvasLayer/SettingsNode/SettingsPosition") as Position2D;
		
		
		
		var bgSpriteOffset = 8;
		//var findDiffference = 0;
		float bgChangerSpeed = 1.5f;
		Vector2 moveToBrown = new Vector2(bgChangeButton1.Position.x + bgSpriteOffset,bgChangeButton1.Position.y + bgSpriteOffset);
		Vector2 moveToGreen = new Vector2(bgChangeButton3.Position.x + bgSpriteOffset,bgChangeButton3.Position.y + bgSpriteOffset);
		Vector2 moveToRed = new Vector2(bgChangeButton4.Position.x + bgSpriteOffset,bgChangeButton4.Position.y + bgSpriteOffset);
		Vector2 moveToBlack = new Vector2(bgChangeButton6.Position.x + bgSpriteOffset,bgChangeButton6.Position.y + bgSpriteOffset);
		Vector2 moveToPurple = new Vector2(bgChangeButton5.Position.x + bgSpriteOffset,bgChangeButton5.Position.y + bgSpriteOffset);
		Vector2 moveToBlue = new Vector2(bgChangeButton7.Position.x + bgSpriteOffset,bgChangeButton7.Position.y + bgSpriteOffset);
		Vector2 moveToPink = new Vector2(bgChangeButton2.Position.x + bgSpriteOffset,bgChangeButton2.Position.y + bgSpriteOffset);
		switch(moveBGChanger)
		{
			case "brown":
			timeToMove += bgChangerSpeed * delta;
			selectBG.Position = selectBG.Position.LinearInterpolate(moveToBrown,timeToMove);
			vectorDifference(selectBG.Position,moveToBrown);
			break;
			
			case "green":
			timeToMove += bgChangerSpeed * delta;
			selectBG.Position = selectBG.Position.LinearInterpolate(moveToGreen,timeToMove);
			vectorDifference(selectBG.Position,moveToGreen);
			break;
			
			case "red":
			timeToMove += bgChangerSpeed * delta;
			selectBG.Position = selectBG.Position.LinearInterpolate(moveToRed,timeToMove);
			vectorDifference(selectBG.Position,moveToRed);
			break;
			
			case "black":
			timeToMove += bgChangerSpeed * delta;
			selectBG.Position = selectBG.Position.LinearInterpolate(moveToBlack,timeToMove);
			vectorDifference(selectBG.Position,moveToBlack);
			break;
			
			case "purple":
			timeToMove += bgChangerSpeed * delta;
			selectBG.Position = selectBG.Position.LinearInterpolate(moveToPurple,timeToMove);
			vectorDifference(selectBG.Position,moveToPurple);
			break;
			
			case "blue":
			timeToMove += bgChangerSpeed * delta;
			selectBG.Position = selectBG.Position.LinearInterpolate(moveToBlue,timeToMove);
			vectorDifference(selectBG.Position,moveToBlue);
			break;
			
			case "pink":
			timeToMove += bgChangerSpeed * delta;
			//bgChangerSpeed += delta;
			selectBG.Position = selectBG.Position.LinearInterpolate(moveToPink,timeToMove);
			vectorDifference(selectBG.Position,moveToPink);
			break;
			
			default:
			timeToMove = 0;
			break;
		}
		
		//Move buttons away, check for if credits or settings was pressed, and enable back button but only that one.
		if(settingsMovement == "Hide Items")
		{
			if(currentScreen == "Select Game")
			{
				if(currentGamePosition.Position.x >= timePos1.Position.x)
				{
					currentGamePosition.Position = new Vector2(timePos1.Position.x, timePos1.Position.y);
				}
				else
				{
					movegameItems.Position += new Vector2(menuMovementSpeed * delta,0);
					currentGamePosition.Position += new Vector2(menuMovementSpeed * delta,0);
					//gameItemsPos.Position += new Vector2(menuMovementSpeed,0);
				}
			}
			else if(currentScreen == "Time Attack")
			{
				if(currentTimePosition.Position.x >= timePos1.Position.x)
				{
					currentTimePosition.Position = new Vector2(timePos1.Position.x, timePos1.Position.y);
				}
				else
				{
					movetimeItems.Position += new Vector2(menuMovementSpeed * delta,0);
					currentTimePosition.Position += new Vector2(menuMovementSpeed * delta,0);
				}
			}
			
			if(titleSprite.Position.y <= newTitlePos.y)
			{
				//titleSprite.Position = new Vector2(titleSprite.Position.x,newTitlePos.y);
			}
			else
			{
				titleSprite.Position -= new Vector2(0, menuMovementSpeed * delta);
			}
			
			if(currentSettingsPos.Position.x <= finalSettingsPos.Position.x)
			{
				//Stop moving here.
				currentSettingsPos.Position = new Vector2(finalSettingsPos.Position.x,finalSettingsPos.Position.y);

			}
			else
			{
				moveSettingsItems.Position += new Vector2(-menuMovementSpeed * delta,0);
				currentSettingsPos.Position += new Vector2(-menuMovementSpeed * delta,0);
			}
		}
		
		if(settingsMovement == "Show Items")
		{
			if(currentScreen == "Select Game")
			{
				if(currentGamePosition.Position.x <= gamePos1.Position.x)
				{
					currentGamePosition.Position = new Vector2(gamePos1.Position.x, gamePos1.Position.y);
					settingsMovement = "";
					disablePress = false;
					return;
				}
				else
				{
					movegameItems.Position -= new Vector2(menuMovementSpeed * delta,0);
					currentGamePosition.Position -= new Vector2(menuMovementSpeed * delta,0);
				}
			}
			else if(currentScreen == "Time Attack")
			{
				if(currentTimePosition.Position.x <= timePos2.Position.x)
				{
					currentTimePosition.Position = new Vector2(timePos2.Position.x, timePos2.Position.y);
					settingsMovement = "";
					disablePress = false;
					creditsMovement.Position = new Vector2(0,300);
					return;
				}
				else
				{
					movetimeItems.Position -= new Vector2(menuMovementSpeed * delta,0);
					currentTimePosition.Position -= new Vector2(menuMovementSpeed * delta,0);
				}
			}
			
			if(titleSprite.Position.y >= oldTitlePos.y)
			{
				//titleSprite.Position = new Vector2(oldTitlePos.x,oldTitlePos.y);
			}
			else
			{
				titleSprite.Position += new Vector2(0, menuMovementSpeed * delta);
			}
			
			if(currentSettingsPos.Position.x >= initSettingsPos.Position.x)
			{
				//Stop moving here.
				currentSettingsPos.Position = new Vector2(initSettingsPos.Position.x,initSettingsPos.Position.y);
			}
			else
			{
				moveSettingsItems.Position += new Vector2(menuMovementSpeed * delta,0);
				currentSettingsPos.Position += new Vector2(menuMovementSpeed * delta,0);
			}
		}
		if(currentScreen == "Time Attack" && moveStep > 0)
		{
			if(moveStep == 1)
			{
			movegameItems.Position += new Vector2(menuMovementSpeed * delta,0);
			currentGamePosition.Position += new Vector2(menuMovementSpeed * delta,0);
			}
			if((currentGamePosition.Position.x >= timePos1.Position.x) && moveStep == 1)
			{
				moveStep += 1;
				currentGamePosition.Position = new Vector2(timePos1.Position.x, timePos1.Position.y);
			}
			
			if(moveStep == 2)
			{
				movetimeItems.Position -= new Vector2(menuMovementSpeed * delta,0);
				currentTimePosition.Position -= new Vector2(menuMovementSpeed * delta,0);
				if(currentTimePosition.Position.x <= timePos2.Position.x)
				{
					disablePress = false;
					moveStep = 0;
					menuMovement = "";
					currentTimePosition.Position = new Vector2(timePos2.Position.x, timePos2.Position.y);
					currentScreen = "Time Attack";
				}
			}
		}
		
		else if(currentScreen == "Select Game" && moveStep > 0)
		{
			if(moveStep == 1)
			{
				movetimeItems.Position += new Vector2(menuMovementSpeed * delta,0);
				currentTimePosition.Position += new Vector2(menuMovementSpeed * delta,0);
				if(currentTimePosition.Position.x >= timePos1.Position.x)
				{
					moveStep += 1;
					currentTimePosition.Position = new Vector2(timePos1.Position.x,timePos1.Position.y);
				}
			}
			
			if(moveStep == 2)
			{
				movegameItems.Position -= new Vector2(menuMovementSpeed * delta,0);
				currentGamePosition.Position -= new Vector2(menuMovementSpeed * delta,0);
				
				if(currentGamePosition.Position.x <= gamePos1.Position.x)
				{
					disablePress = false;
					moveStep = 0;
					menuMovement = "";
					//movegameItems.Position = new Vector2(gamePos1.Position.x,gamePos1.Position.x);
					currentGamePosition.Position = new Vector2(gamePos1.Position.x,gamePos1.Position.y);
					currentScreen = "Select Game";
				}
			}
		}
		
	//Update position of the backgrounds, and multiply by delta time. 
		int x = 0;
		if(sceneTransition.saveDict["backgroundScrolling"].ToString() == "true")
		{
			foreach(Sprite i in parallaxBackground.GetChildren())
			{
				i.Position -= new Vector2 (parallaxSpeeds[x] * delta,0);
		//Texture width may vary depending on size of background.
				if(i.Position.x <= -i.Texture.GetWidth() / 4)
					i.Position = new Vector2(0,i.Position.y);
				x++;
			}
		}
	}
	
	private void _on_BGChange1_pressed()
	{
		currentChangerPos = new Vector2(selectBG.Position.x,selectBG.Position.y);
		int x = 5;
		var five = (Sprite)parallaxBackground.GetChild(4);
		var four = (Sprite)parallaxBackground.GetChild(3);
		var three = (Sprite)parallaxBackground.GetChild(2);
		var two = (Sprite)parallaxBackground.GetChild(1);
		var one = (Sprite)parallaxBackground.GetChild(0);
		if(sceneTransition.saveDict["backgroundColor"].ToString() != "brown")
		{
			timeToMove = 0;
			one.Texture = brownTexture5;
			two.Texture = brownTexture4;
			three.Texture = brownTexture3;
			four.Texture = brownTexture2;
			five.Texture = brownTexture1;
			sceneTransition.playMenuSelect();
		}
		sceneTransition.saveDict["backgroundColor"] = "brown";
		sceneTransition.SaveGame();
		moveBGChanger = "brown";
		//Get position of item, and tell BGChanger to lerp there.
	}
	
	private void _on_BGChange3_pressed()
	{
		currentChangerPos = new Vector2(selectBG.Position.x,selectBG.Position.y);
		int x = 5;
		var five = (Sprite)parallaxBackground.GetChild(4);
		var four = (Sprite)parallaxBackground.GetChild(3);
		var three = (Sprite)parallaxBackground.GetChild(2);
		var two = (Sprite)parallaxBackground.GetChild(1);
		var one = (Sprite)parallaxBackground.GetChild(0);
		if(sceneTransition.saveDict["backgroundColor"].ToString() != "green")
		{
			timeToMove = 0;
			one.Texture = greenTexture5;
			two.Texture = greenTexture4;
			three.Texture = greenTexture3;
			four.Texture = greenTexture2;
			five.Texture = greenTexture1;
			sceneTransition.playMenuSelect();
		}
		sceneTransition.saveDict["backgroundColor"] = "green";
		sceneTransition.SaveGame();
		moveBGChanger = "green";
	}
	
	private void _on_BGChange4_pressed()
	{
		currentChangerPos = new Vector2(selectBG.Position.x,selectBG.Position.y);
		int x = 5;
		var five = (Sprite)parallaxBackground.GetChild(4);
		var four = (Sprite)parallaxBackground.GetChild(3);
		var three = (Sprite)parallaxBackground.GetChild(2);
		var two = (Sprite)parallaxBackground.GetChild(1);
		var one = (Sprite)parallaxBackground.GetChild(0);
		if(sceneTransition.saveDict["backgroundColor"].ToString() != "red")
		{
			timeToMove = 0;
			one.Texture = redTexture5;
			two.Texture = redTexture4;
			three.Texture = redTexture3;
			four.Texture = redTexture2;
			five.Texture = redTexture1;
			sceneTransition.playMenuSelect();
		}
		sceneTransition.saveDict["backgroundColor"] = "red";
		sceneTransition.SaveGame();
		moveBGChanger = "red";
	}
	
	private void _on_BGChange6_pressed()
	{
		currentChangerPos = new Vector2(selectBG.Position.x,selectBG.Position.y);
		int x = 5;
		var five = (Sprite)parallaxBackground.GetChild(4);
		var four = (Sprite)parallaxBackground.GetChild(3);
		var three = (Sprite)parallaxBackground.GetChild(2);
		var two = (Sprite)parallaxBackground.GetChild(1);
		var one = (Sprite)parallaxBackground.GetChild(0);
		if(sceneTransition.saveDict["backgroundColor"].ToString() != "black")
		{
			timeToMove = 0;
			one.Texture = blackTexture5;
			two.Texture = blackTexture4;
			three.Texture = blackTexture3;
			four.Texture = blackTexture2;
			five.Texture = blackTexture1;
			sceneTransition.playMenuSelect();
		}
		sceneTransition.saveDict["backgroundColor"] = "black";
		sceneTransition.SaveGame();
		moveBGChanger = "black";
	}
	
	private void _on_BGChange5_pressed()
	{
		currentChangerPos = new Vector2(selectBG.Position.x,selectBG.Position.y);
		int x = 5;
		var five = (Sprite)parallaxBackground.GetChild(4);
		var four = (Sprite)parallaxBackground.GetChild(3);
		var three = (Sprite)parallaxBackground.GetChild(2);
		var two = (Sprite)parallaxBackground.GetChild(1);
		var one = (Sprite)parallaxBackground.GetChild(0);
		if(sceneTransition.saveDict["backgroundColor"].ToString() != "purple")
		{
			timeToMove = 0;
			one.Texture = purpleTexture5;
			two.Texture = purpleTexture4;
			three.Texture = purpleTexture3;
			four.Texture = purpleTexture2;
			five.Texture = purpleTexture1;
			sceneTransition.playMenuSelect();
		}
		sceneTransition.saveDict["backgroundColor"] = "purple";
		sceneTransition.SaveGame();
		moveBGChanger = "purple";
	}
	
	private void _on_BGChange2_pressed()
	{
		currentChangerPos = new Vector2(selectBG.Position.x,selectBG.Position.y);
		int x = 5;
		var five = (Sprite)parallaxBackground.GetChild(4);
		var four = (Sprite)parallaxBackground.GetChild(3);
		var three = (Sprite)parallaxBackground.GetChild(2);
		var two = (Sprite)parallaxBackground.GetChild(1);
		var one = (Sprite)parallaxBackground.GetChild(0);
		if(sceneTransition.saveDict["backgroundColor"].ToString() != "pink")
		{
			timeToMove = 0;
			one.Texture = pinkTexture5;
			two.Texture = pinkTexture4;
			three.Texture = pinkTexture3;
			four.Texture = pinkTexture2;
			five.Texture = pinkTexture1;
			sceneTransition.playMenuSelect();
		}
		sceneTransition.saveDict["backgroundColor"] = "pink";
		sceneTransition.SaveGame();
		moveBGChanger = "pink";
	}
	
	private void _on_BGChange7_pressed()
	{
		currentChangerPos = new Vector2(selectBG.Position.x,selectBG.Position.y);
		int x = 5;
		var five = (Sprite)parallaxBackground.GetChild(4);
		var four = (Sprite)parallaxBackground.GetChild(3);
		var three = (Sprite)parallaxBackground.GetChild(2);
		var two = (Sprite)parallaxBackground.GetChild(1);
		var one = (Sprite)parallaxBackground.GetChild(0);
		if(sceneTransition.saveDict["backgroundColor"].ToString() != "blue")
		{
			sceneTransition.playMenuSelect();
			timeToMove = 0;
			one.Texture = blueTexture5;
			two.Texture = blueTexture4;
			three.Texture = blueTexture3;
			four.Texture = blueTexture2;
			five.Texture = blueTexture1;
		}
		sceneTransition.saveDict["backgroundColor"] = "blue";
		sceneTransition.SaveGame();
		moveBGChanger = "blue";
	}
	
	private void UpdateBG()
	{
		var five = (Sprite)parallaxBackground.GetChild(4);
		var four = (Sprite)parallaxBackground.GetChild(3);
		var three = (Sprite)parallaxBackground.GetChild(2);
		var two = (Sprite)parallaxBackground.GetChild(1);
		var one = (Sprite)parallaxBackground.GetChild(0);
		
		
		var bgSpriteOffset = 8;
		
		Vector2 moveToBrown = new Vector2(bgChangeButton1.Position.x + bgSpriteOffset,bgChangeButton1.Position.y + bgSpriteOffset);
		Vector2 moveToGreen = new Vector2(bgChangeButton3.Position.x + bgSpriteOffset,bgChangeButton3.Position.y + bgSpriteOffset);
		Vector2 moveToRed = new Vector2(bgChangeButton4.Position.x + bgSpriteOffset,bgChangeButton4.Position.y + bgSpriteOffset);
		Vector2 moveToBlack = new Vector2(bgChangeButton6.Position.x + bgSpriteOffset,bgChangeButton6.Position.y + bgSpriteOffset);
		Vector2 moveToPurple = new Vector2(bgChangeButton5.Position.x + bgSpriteOffset,bgChangeButton5.Position.y + bgSpriteOffset);
		Vector2 moveToBlue = new Vector2(bgChangeButton7.Position.x + bgSpriteOffset,bgChangeButton7.Position.y + bgSpriteOffset);
		Vector2 moveToPink = new Vector2(bgChangeButton2.Position.x + bgSpriteOffset,bgChangeButton2.Position.y + bgSpriteOffset);
		
		switch(sceneTransition.saveDict["backgroundColor"].ToString())
		{
			case"red":
			one.Texture = redTexture5;
			two.Texture = redTexture4;
			three.Texture = redTexture3;
			four.Texture = redTexture2;
			five.Texture = redTexture1;
			selectBG.Position = new Vector2(moveToRed.x,moveToRed.y);
			break;
			case"blue":
			one.Texture = blueTexture5;
			two.Texture = blueTexture4;
			three.Texture = blueTexture3;
			four.Texture = blueTexture2;
			five.Texture = blueTexture1;
			selectBG.Position = new Vector2(moveToBlue.x,moveToBlue.y);
			break;
			case"brown":
			one.Texture = brownTexture5;
			two.Texture = brownTexture4;
			three.Texture = brownTexture3;
			four.Texture = brownTexture2;
			five.Texture = brownTexture1;
			selectBG.Position = new Vector2(moveToBrown.x,moveToBrown.y);
			break;
			case"black":
			one.Texture = blackTexture5;
			two.Texture = blackTexture4;
			three.Texture = blackTexture3;
			four.Texture = blackTexture2;
			five.Texture = blackTexture1;
			selectBG.Position = new Vector2(moveToBlack.x,moveToBlack.y);
			break;
			case"pink":
			one.Texture = pinkTexture5;
			two.Texture = pinkTexture4;
			three.Texture = pinkTexture3;
			four.Texture = pinkTexture2;
			five.Texture = pinkTexture1;
			selectBG.Position = new Vector2(moveToPink.x,moveToPink.y);
			break;
			case"purple":
			one.Texture = purpleTexture5;
			two.Texture = purpleTexture4;
			three.Texture = purpleTexture3;
			four.Texture = purpleTexture2;
			five.Texture = purpleTexture1;
			selectBG.Position = new Vector2(moveToPurple.x,moveToPurple.y);
			break;
			case"green":
			one.Texture = greenTexture5;
			two.Texture = greenTexture4;
			three.Texture = greenTexture3;
			four.Texture = greenTexture2;
			five.Texture = greenTexture1;
			selectBG.Position = new Vector2(moveToGreen.x,moveToGreen.y);
			break;
			
			default:
			break;
		}

	}
	
	private void _on_MuteMusicBtn_pressed()
	{
		sceneTransition.playMenuSelect();
		string checkMuteSound = sceneTransition.saveDict["muteMusic"].ToString();
		var disableAnim = GetNode("CanvasLayer/SettingsControl/SettingsItems/ButtonAnimations") as AnimationPlayer;
		var busIndex = AudioServer.GetBusIndex("Music");
		if(checkMuteSound == "true")
		{
			disableAnim.Play("MuteMusicButton");
			sceneTransition.saveDict["muteMusic"] = "false";
	
		}
		else
		{
			disableAnim.Play("MuteMusicReverse");
			sceneTransition.saveDict["muteMusic"] = "true";
		}
		AudioServer.SetBusMute(busIndex, !AudioServer.IsBusMute(busIndex));
		sceneTransition.SaveGame();
	}


	private void _on_MuteSoundBtn_pressed()
	{
		sceneTransition.playMenuSelect();
		string checkMuteSound = sceneTransition.saveDict["muteSound"].ToString();
		var disableAnim = GetNode("CanvasLayer/SettingsControl/SettingsItems/ButtonAnimations") as AnimationPlayer;
		var busIndex = AudioServer.GetBusIndex("SFX");
		if(checkMuteSound == "true")
		{
			disableAnim.Play("MuteSoundButton");
			sceneTransition.saveDict["muteSound"] = "false";
		}
		else
		{
			disableAnim.Play("MuteSoundReverse");
			sceneTransition.saveDict["muteSound"] = "true";
		}
		AudioServer.SetBusMute(busIndex, !AudioServer.IsBusMute(busIndex));
		sceneTransition.SaveGame();
	}
	
	private void _on_DisableScrollBtn_pressed()
	{
		sceneTransition.playMenuSelect();
		string checkScroll = sceneTransition.saveDict["backgroundScrolling"].ToString();
		var disableAnim = GetNode("CanvasLayer/SettingsControl/SettingsItems/ButtonAnimations") as AnimationPlayer;
		if(checkScroll == "true")
		{
			disableAnim.Play("DisableScrollingButton");
			sceneTransition.saveDict["backgroundScrolling"] = "false";
		}
		else
		{
			disableAnim.Play("DisableScrollingReverse");
			sceneTransition.saveDict["backgroundScrolling"] = "true";
		}
		sceneTransition.SaveGame();
	}
	

	
	private void _on_SettingsWindow_pressed()
	{
		if(!disablePress)
		{
			sceneTransition.playMenuSelect();
			settingsMovement = "Hide Items";
			//Begin showing credits here.
			settings_Control.Position = new Vector2(0,0);
			settingsPlayer.Play("SettingsAnimation");
			disablePress = true;
		}

	}
	
	private void _on_SettingsBackBtn_pressed()
	{
		if(!disablePress)
		{
			sceneTransition.playBackSelect();
			settingsMovement = "Show Items";
			settingsPlayer.Play("SettingsAnimationReverse");
			disablePress = true;
		}
		Node2D GetSettingsButtons = GetNode("CanvasLayer/SettingsControl/SettingsItems/SettingsButtons") as Node2D;
		foreach(TouchScreenButton i in GetSettingsButtons.GetChildren())
		{
			i.SetBlockSignals(true);
		}
	}
	
	private void _on_CreditsWindow_pressed()
	{
		if(!disablePress)
		{
			sceneTransition.playMenuSelect();
			settingsMovement = "Hide Items";
			//Begin showing credits here.
			creditsMovement.Position = new Vector2(0,0);
			creditsPlayer.Play("CreditsAnimation");
			
			disablePress = true;
		}
	}
	
	private void _on_BackButton_pressed()
	{
		if(!disablePress)
		{
			sceneTransition.playBackSelect();
			settingsMovement = "Show Items";
			
			creditsPlayer.Play("CreditsAnimationBackwards");
			disablePress = true;
		}
	}
	
	private void _on_ClassicWindow_pressed()
	{
		if(!disablePress)
		{
			sceneTransition.gameType = "classicMode";
			sceneTransition.playMenuSelect();
			sceneTransition.SwitchScenes("res://Main_Game.tscn");
			disablePress = true;
		}
	}
	
	private void _on_ScoreAttackWindow_pressed()
	{
		if(!disablePress)
		{
			sceneTransition.gameType = "scoreAttack";
			sceneTransition.playMenuSelect();
			sceneTransition.SwitchScenes("res://Main_Game.tscn");
			disablePress = true;
		}
	}
	
	private void _on_TimeAttackWindow_pressed()
	{
		if(!disablePress)
		{
			sceneTransition.gameType = "timeAttack";
			sceneTransition.playMenuSelect();
			currentScreen = "Time Attack";
			moveStep = 1; //Start movement
			disablePress = true;
		}
	}
	
	private void _on_backBtn_pressed()
	{
		if(!disablePress)
		{
			sceneTransition.gameType = "";
			sceneTransition.playBackSelect();
			currentScreen = "Select Game";
			moveStep = 1; //Start movement
			disablePress = true;
		}
	}
	
	private void _on_thirtySecondsBtn_pressed()
	{
		if(!disablePress)
		{
			sceneTransition.gameTimer = "thirtySeconds";
			sceneTransition.SwitchScenes("res://Main_Game.tscn");
			sceneTransition.playMenuSelect();
			disablePress = true;
		}
	}
	
	private void _on_oneMinuteBtn_pressed()
	{
		if(!disablePress)
		{
			sceneTransition.gameTimer = "oneMinute";
			sceneTransition.SwitchScenes("res://Main_Game.tscn");
			sceneTransition.playMenuSelect();
			disablePress = true;
		}
	}
	
	private void _on_threeMinuteBtn_pressed()
	{
		if(!disablePress)
		{
			sceneTransition.gameTimer = "threeMinute";
			sceneTransition.SwitchScenes("res://Main_Game.tscn");
			sceneTransition.playMenuSelect();
			disablePress = true;
		}
	}

	private void _on_fiveMinBtn_pressed()
	{
		if(!disablePress)
		{
			sceneTransition.gameTimer = "fiveMinute";
			sceneTransition.SwitchScenes("res://Main_Game.tscn");
			sceneTransition.playMenuSelect();
			disablePress = true;
		}
	}
	
	private void _on_tenMinBtn_pressed()
	{
		if(!disablePress)
		{
			sceneTransition.gameTimer = "tenMinute";
			sceneTransition.SwitchScenes("res://Main_Game.tscn");
			sceneTransition.playMenuSelect();
			disablePress = true;
		}
	}

	private void _on_CreditsAnimation_animation_finished(String anim_name)
	{
		disablePress = false;
		if(anim_name == "CreditsAnimationBackwards")
		{
			creditsMovement.Position = new Vector2(0,300);
		}
	}

	private void _on_SettingsAnimate_animation_finished(String anim_name)
	{
		disablePress = false;
		if(anim_name == "SettingsAnimationReverse")
		{
			settings_Control.Position = new Vector2(0,-300);
		}
		if(anim_name == "SettingsAnimation")
		{
			Node2D GetSettingsButtons = GetNode("CanvasLayer/SettingsControl/SettingsItems/SettingsButtons") as Node2D;
			foreach(TouchScreenButton i in GetSettingsButtons.GetChildren())
			{
				i.SetBlockSignals(false);
			}
		}
	}
	
	private void _on_PrevSongBtn_released()
	{
		sceneTransition.playButton();
		sceneTransition.PlayPreviousSong();
	}
	
	private void _on_NextSongBtn_released()
	{
		sceneTransition.playButton();
		sceneTransition.PlayNextSong();
	}
	
	private void _on_PlaySongBtn_released()
	{
		sceneTransition.playButton();
		sceneTransition.PauseMusic();
	}
	
	private void _on_LoopSongBtn_released()
	{
		sceneTransition.playButton();
		sceneTransition.LoopSong();
	}
}





































