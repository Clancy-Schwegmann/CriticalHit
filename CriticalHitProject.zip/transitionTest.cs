using Godot;
using System;

public class transitionTest : Control
{
	public bool isSignedIn = false;
	//Music stuff
		public string[] songQueue = 
		{"Storm Trap","Evening Mood","Zero One",
		"Down the Well","Ripples on the Water","Gambling Bonnie"};
		//Determines what song is playing.
		//0 - urchin, 1 - evening mood, 2 - ellipse, 3 - down the well.
		public long currentSong = 0;
		private AudioStream rippleSong;
		private AudioStream stormSong;
		private AudioStream bonnieSong;
		private AudioStream eveningSong;
		private AudioStream zeroSong;
		private AudioStream downSong;
		private AudioStream hitSound;
		private AudioStream deathSound;
		private AudioStream menuSound;
		private AudioStream goBackSound;
		private AudioStream newHitSound;
		private AudioStream buttonSound;
		
		public bool isPaused = false;
		public bool isLooping = false;
		private float playbackPosition = 0;
	
	//This mutes SFX and music.
	public bool muteSound = false;
	
	public bool initSong = false;
	
	
	public bool startGame = true;
	//Use this to determine what game settings were picked.
	//Settings - classicMode,timeAttack,scoreAttack
	public string gameType = "";
	
	//Try to make scaling difficulty first.
	//public string gameDifficulty = "";
	
	//thirtySeconds,oneMinute,threeMinute,fiveMinute,tenMinute
	public string gameTimer = "";

	private PackedScene getScene;
	private MainNode startScene;
	private AnimationPlayer playAnimation;
	private AudioStreamPlayer getSong;
	private AudioStreamPlayer getSFX;
	//Call this string to change the transition type. "Fade to black", will fade the scene to black.
	public string transitionType = "fadeBlack";


		//Directory path.
	private const string saveDir = "user://saved_data/";
	//Save and load file name path.
	private string savefilePath = saveDir + "SaveData.json";
	
	public Godot.Collections.Dictionary<string,object> saveDict = new Godot.Collections.Dictionary<string,object>()
	{
		{"favoriteSong",""},
		{"backgroundColor","green"},
		{"backgroundScrolling","true"},
		{"muteMusic","true"},
		{"muteSound","true"},
		{"classicMode","0"},
		{"scoreAttack","0"},
		{"timeAttack - thirtySeconds","0"},
		{"timeAttack - oneMinute","0"},
		{"timeAttack - threeMinute","0"},
		{"timeAttack - fiveMinute","0"},
		{"timeAttack - tenMinute","0"},
	};
	
	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
		GD.Randomize();
		getSong = GetNode("../SongPlayer") as AudioStreamPlayer;
		getSFX = GetNode("../SoundEffectsPlayer") as AudioStreamPlayer;
		
		//hitSound = ResourceLoader.Load($"res://Music+SFX/hitV2.mp3") as AudioStream;
		hitSound = ResourceLoader.Load($"res://Music+SFX/explosionSound.mp3") as AudioStream;
		deathSound = ResourceLoader.Load($"res://Music+SFX/deathSound.mp3") as AudioStream;
		menuSound = ResourceLoader.Load($"res://Music+SFX/menuSound.mp3") as AudioStream;
		goBackSound = ResourceLoader.Load($"res://Music+SFX/backSelect.mp3") as AudioStream;
		buttonSound = ResourceLoader.Load($"res://Music+SFX/buttonSound.mp3") as AudioStream;
		
		stormSong = ResourceLoader.Load($"res://Music+SFX/ES_Storm Trap - Giants' Nest (compressed).mp3") as AudioStream;
		bonnieSong = ResourceLoader.Load($"res://Music+SFX/ES_Gambling Bonnie - Harvio (compressed).mp3") as AudioStream;
		rippleSong = ResourceLoader.Load($"res://Music+SFX/ES_Ripples on the Water - Nebulae (compressed).mp3") as AudioStream;
		zeroSong = ResourceLoader.Load($"res://Music+SFX/ES_Zero One - Young Community (compressed).mp3") as AudioStream;
		downSong = ResourceLoader.Load($"res://Music+SFX/ES_Down the Well - Out Linear (compressed).mp3") as AudioStream;
		eveningSong = ResourceLoader.Load($"res://Music+SFX/ES_Evening Mood - Sum Wave (compressed).mp3") as AudioStream;
	}


	private void _on_SongPlayer_finished()
	{
		if(!getSong.IsPlaying())
		{
			//Check if looping or not.
			if(!isLooping)
			{
				currentSong ++;
				if(currentSong > songQueue.Length - 1)
				{
					currentSong = 0;
				}
			}
			generateSong();
			isPaused = false;
			getSong.StreamPaused = false;
		}
	}
	
	public void playDead()
	{
		getSFX.Stream = deathSound;
			getSFX.Play();
	}
	
	public void playButton()
	{
		getSFX.Stream = buttonSound;
		getSFX.Play();
	}
	
	public void playHit()
	{
		getSFX.Stream = hitSound;
			getSFX.Play();
	}
	
	public void playMenuSelect()
	{
		getSFX.Stream = menuSound;
			getSFX.Play();
	}
	
	public void playBackSelect()
	{
		getSFX.Stream = goBackSound;
		getSFX.Play();
	}
	
	public void LoopSong()
	{
		isLooping = !isLooping;
		if(!isLooping)
			saveDict["favoriteSong"] = "";
		else
			saveDict["favoriteSong"] = songQueue[currentSong];
		SaveGame();
	}

	public void PlayNextSong()
	{
		currentSong ++;
		if(currentSong > songQueue.Length - 1)
		{
			currentSong = 0;
		}
		generateSong();
		isPaused = false;
		isLooping = false;
		saveDict["favoriteSong"] = "";
		getSong.StreamPaused = false;
		SaveGame();
	}
	
	public void PlayPreviousSong()
	{
		currentSong --;
		if(currentSong < 0)
		{
			currentSong = songQueue.Length - 1;
		}
		generateSong();
		isPaused = false;
		isLooping = false;
		saveDict["favoriteSong"] = "";
		getSong.StreamPaused = false;
		SaveGame();
	}

	public void PauseMusic()
	{
		//Flip variable.
		isPaused = !isPaused;
		if(isPaused)
			getSong.StreamPaused = true;
		else
			getSong.StreamPaused = false;
	}
	


	private void generateSong()
	{
		if(songQueue[currentSong] == "Storm Trap")
		{
			getSong.Stream = stormSong;
		}
		else if(songQueue[currentSong] == "Evening Mood")
		{
			getSong.Stream = eveningSong;
		}
		else if(songQueue[currentSong] == "Zero One")
		{
			getSong.Stream = zeroSong;
		}
		else if(songQueue[currentSong] == "Down the Well")
		{
			getSong.Stream = downSong;
		}
		else if(songQueue[currentSong] == "Gambling Bonnie")
		{
			getSong.Stream = bonnieSong;
		}
		else if(songQueue[currentSong] == "Ripples on the Water")
		{
			getSong.Stream = rippleSong;
		}
		getSong.Play();
	}

	public void songStart()
	{
		//Only run this once.
		if(saveDict["favoriteSong"].ToString() != "")
		{
			currentSong = Array.IndexOf(songQueue,saveDict["favoriteSong"].ToString());
			generateSong();
			initSong = true;
			return;
		}
		long getRand = 0;
		getRand = GD.Randi() % songQueue.Length;
		currentSong = getRand;
		
		generateSong();
		initSong = true;
	}
	
	public void fadeOut()
	{
		playAnimation = GetNode("scenePlayer") as AnimationPlayer;
		playAnimation.Play("FadeToBlack");
	}
		public void fadeIn()
	{
		playAnimation = GetNode("scenePlayer") as AnimationPlayer;
		playAnimation.Play("FadeToNormal");
	}
	
	//args (scene path)
	public async void SwitchScenes(string scenePath)
	{
	playAnimation = GetNode("scenePlayer") as AnimationPlayer;
//	getScene = (PackedScene)ResourceLoader.Load("res://Main_Game.tscn");
//	instancedScene = getScene.Instance();
	//startScene = GetTree().GetRoot().GetNode<MainNode>("MainNode");
	//startScene = instancedScene.GetNode<Main_Node>("root/Main_Node");
	
	playAnimation.Play("FadeToBlack");
	await ToSignal(playAnimation,"animation_finished");
	GetTree().ChangeScene(scenePath);
	playAnimation.Play("FadeToNormal");
	startGame = false;
	
	await ToSignal(playAnimation, "animation_finished");
	startGame = true;
	//GetTree().ChangeScene("res://Main_Game.tscn");
	}
	
	//Update best scores and mute sound here.
	public void SaveGame()
	{
		//Just save data here, let the other classes update items as they need.
		
		var dir = new Directory();
		if(!dir.DirExists(saveDir))
			dir.MakeDirRecursive(saveDir);
			
			
			//Now let's save these dictionary variables. First declare new file type.
		var file = new File();
		
		//write data to file and encrypt it so it's harder to access.
		//Maybe add error check if needed later.
		file.OpenEncryptedWithPass(savefilePath,File.ModeFlags.Write,"Salty_Hashbrowns");
		file.StoreLine(JSON.Print(saveDict));
		file.Close();
	}
	
	public void LoadGame()
	{
		var file = new File();
		if(!file.FileExists(savefilePath)) 
			return;
		file.OpenEncryptedWithPass(savefilePath,File.ModeFlags.Read,"Salty_Hashbrowns");
		//Loop through each character in the text to find the right dictionary item to update.
		while (file.GetPosition() < file.GetLen())
		{
			var saveData = new Godot.Collections.Dictionary<string, object>((Godot.Collections.Dictionary)JSON.Parse(file.GetLine()).Result);
			
			
			//Update bottom font which is the high-score. Save this to leaderboard later as well.
				saveDict["favoriteSong"] = saveData["favoriteSong"].ToString();
				saveDict["backgroundColor"] = saveData["backgroundColor"].ToString();
				saveDict["backgroundScrolling"] = saveData["backgroundScrolling"].ToString();
				saveDict["muteMusic"] = saveData["muteMusic"].ToString();
				saveDict["muteSound"] = saveData["muteSound"].ToString();
				saveDict["classicMode"] = saveData["classicMode"].ToString();
				saveDict["scoreAttack"] = saveData["scoreAttack"].ToString();
				saveDict["timeAttack - thirtySeconds"] = saveData["timeAttack - thirtySeconds"].ToString();
				saveDict["timeAttack - oneMinute"] = saveData["timeAttack - oneMinute"].ToString();
				saveDict["timeAttack - threeMinute"] = saveData["timeAttack - threeMinute"].ToString();
				saveDict["timeAttack - fiveMinute"] = saveData["timeAttack - fiveMinute"].ToString();
				saveDict["timeAttack - tenMinute"] = saveData["timeAttack - tenMinute"].ToString();
				
				if(saveData["muteSound"].ToString() == "false")
					muteSound = false;
				else
					muteSound = true;
			
		}
		file.Close();
	}
	
}










