using Godot;
using System;

public class IntroScene : Node2D
{
	// Declare member variables here. Examples:
	// private int a = 2;
	// private string b = "text";
	//Autoloaded script, used for transitioning scenes.
		private AnimationPlayer newAnimator;
		private transitionTest sceneTransition;
		//How long the intro-scene lasts.
		private int sceneTimer = 3; 
		private Timer frameTime;
		private bool runCheck = false;
		private int animationPlayed = 0;
	// Called when the node enters the scene tree for the first time.
	
	private void _on_scenePlayer_animation_finished(String FadeOutIntro)
	{
		if(sceneTimer == 0)
			sceneTransition.SwitchScenes("res://Main_Menu.tscn");
	}
	
	public override void _Ready()
	{
		sceneTransition = GetNode<transitionTest>("/root/sceneSwitcher/transitionTest");
		frameTime = GetNode("Timer") as Timer; 
		newAnimator = GetNode("CanvasLayer/Control/scenePlayer") as AnimationPlayer;
		
		frameTime.Start();
		//Sign In here
		var googlePlayer = GetNode("/root/leaderboardSystem");
		googlePlayer.Call("SignOn");
	}

//  // Called every frame. 'delta' is the elapsed time since the previous frame.
  public override void _Process(float delta)
	{
		
		if(sceneTimer == 2 && animationPlayed == 0)
		{
			newAnimator.Play("FadeInIntro");
			animationPlayed = 1;
		}
		
		if(sceneTimer == 0 && animationPlayed == 1)
		{
			newAnimator.Play("FadeOutIntro");
			animationPlayed = 2;
		}
		
		if(frameTime.IsStopped())
		{
			sceneTimer--;
			frameTime.Start();
		}
	}
}


